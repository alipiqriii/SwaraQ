-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 03, 2018 at 07:50 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `metro`
--

-- --------------------------------------------------------

--
-- Table structure for table `autocomplete`
--

CREATE TABLE `autocomplete` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL DEFAULT '',
  `alpha_2` varchar(2) NOT NULL DEFAULT '',
  `alpha_3` varchar(3) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `autocomplete`
--

INSERT INTO `autocomplete` (`id`, `name`, `alpha_2`, `alpha_3`) VALUES
(1, 'Afghanistan', 'af', 'afg'),
(2, 'Aland Islands', 'ax', 'ala'),
(3, 'Albania', 'al', 'alb'),
(4, 'Algeria', 'dz', 'dza'),
(5, 'American Samoa', 'as', 'asm'),
(6, 'Andorra', 'ad', 'and'),
(7, 'Angola', 'ao', 'ago'),
(8, 'Anguilla', 'ai', 'aia'),
(9, 'Antarctica', 'aq', ''),
(10, 'Antigua and Barbuda', 'ag', 'atg'),
(11, 'Argentina', 'ar', 'arg'),
(12, 'Armenia', 'am', 'arm'),
(13, 'Aruba', 'aw', 'abw'),
(14, 'Australia', 'au', 'aus'),
(15, 'Austria', 'at', 'aut'),
(16, 'Azerbaijan', 'az', 'aze'),
(17, 'Bahamas', 'bs', 'bhs'),
(18, 'Bahrain', 'bh', 'bhr'),
(19, 'Bangladesh', 'bd', 'bgd'),
(20, 'Barbados', 'bb', 'brb'),
(21, 'Belarus', 'by', 'blr'),
(22, 'Belgium', 'be', 'bel'),
(23, 'Belize', 'bz', 'blz'),
(24, 'Benin', 'bj', 'ben'),
(25, 'Bermuda', 'bm', 'bmu'),
(26, 'Bhutan', 'bt', 'btn'),
(27, 'Bolivia, Plurinational State of', 'bo', 'bol'),
(28, 'Bonaire, Sint Eustatius and Saba', 'bq', 'bes'),
(29, 'Bosnia and Herzegovina', 'ba', 'bih'),
(30, 'Botswana', 'bw', 'bwa'),
(31, 'Bouvet Island', 'bv', ''),
(32, 'Brazil', 'br', 'bra'),
(33, 'British Indian Ocean Territory', 'io', ''),
(34, 'Brunei Darussalam', 'bn', 'brn'),
(35, 'Bulgaria', 'bg', 'bgr'),
(36, 'Burkina Faso', 'bf', 'bfa'),
(37, 'Burundi', 'bi', 'bdi'),
(38, 'Cambodia', 'kh', 'khm'),
(39, 'Cameroon', 'cm', 'cmr'),
(40, 'Canada', 'ca', 'can'),
(41, 'Cape Verde', 'cv', 'cpv'),
(42, 'Cayman Islands', 'ky', 'cym'),
(43, 'Central African Republic', 'cf', 'caf'),
(44, 'Chad', 'td', 'tcd'),
(45, 'Chile', 'cl', 'chl'),
(46, 'China', 'cn', 'chn'),
(47, 'Christmas Island', 'cx', ''),
(48, 'Cocos (Keeling) Islands', 'cc', ''),
(49, 'Colombia', 'co', 'col'),
(50, 'Comoros', 'km', 'com'),
(51, 'Congo', 'cg', 'cog'),
(52, 'Congo, The Democratic Republic of the', 'cd', 'cod'),
(53, 'Cook Islands', 'ck', 'cok'),
(54, 'Costa Rica', 'cr', 'cri'),
(55, 'Cote d\'Ivoire', 'ci', 'civ'),
(56, 'Croatia', 'hr', 'hrv'),
(57, 'Cuba', 'cu', 'cub'),
(58, 'Curacao', 'cw', 'cuw'),
(59, 'Cyprus', 'cy', 'cyp'),
(60, 'Czech Republic', 'cz', 'cze'),
(61, 'Denmark', 'dk', 'dnk'),
(62, 'Djibouti', 'dj', 'dji'),
(63, 'Dominica', 'dm', 'dma'),
(64, 'Dominican Republic', 'do', 'dom'),
(65, 'Ecuador', 'ec', 'ecu'),
(66, 'Egypt', 'eg', 'egy'),
(67, 'El Salvador', 'sv', 'slv'),
(68, 'Equatorial Guinea', 'gq', 'gnq'),
(69, 'Eritrea', 'er', 'eri'),
(70, 'Estonia', 'ee', 'est'),
(71, 'Ethiopia', 'et', 'eth'),
(72, 'Falkland Islands (Malvinas)', 'fk', 'flk'),
(73, 'Faroe Islands', 'fo', 'fro'),
(74, 'Fiji', 'fj', 'fji'),
(75, 'Finland', 'fi', 'fin'),
(76, 'France', 'fr', 'fra'),
(77, 'French Guiana', 'gf', 'guf'),
(78, 'French Polynesia', 'pf', 'pyf'),
(79, 'French Southern Territories', 'tf', ''),
(80, 'Gabon', 'ga', 'gab'),
(81, 'Gambia', 'gm', 'gmb'),
(82, 'Georgia', 'ge', 'geo'),
(83, 'Germany', 'de', 'deu'),
(84, 'Ghana', 'gh', 'gha'),
(85, 'Gibraltar', 'gi', 'gib'),
(86, 'Greece', 'gr', 'grc'),
(87, 'Greenland', 'gl', 'grl'),
(88, 'Grenada', 'gd', 'grd'),
(89, 'Guadeloupe', 'gp', 'glp'),
(90, 'Guam', 'gu', 'gum'),
(91, 'Guatemala', 'gt', 'gtm'),
(92, 'Guernsey', 'gg', 'ggy'),
(93, 'Guinea', 'gn', 'gin'),
(94, 'Guinea-Bissau', 'gw', 'gnb'),
(95, 'Guyana', 'gy', 'guy'),
(96, 'Haiti', 'ht', 'hti'),
(97, 'Heard Island and McDonald Islands', 'hm', ''),
(98, 'Holy See (Vatican City State)', 'va', 'vat'),
(99, 'Honduras', 'hn', 'hnd'),
(100, 'Hong Kong', 'hk', 'hkg'),
(101, 'Hungary', 'hu', 'hun'),
(102, 'Iceland', 'is', 'isl'),
(103, 'India', 'in', 'ind'),
(104, 'Indonesia', 'id', 'idn'),
(105, 'Iran, Islamic Republic of', 'ir', 'irn'),
(106, 'Iraq', 'iq', 'irq'),
(107, 'Ireland', 'ie', 'irl'),
(108, 'Isle of Man', 'im', 'imn'),
(109, 'Israel', 'il', 'isr'),
(110, 'Italy', 'it', 'ita'),
(111, 'Jamaica', 'jm', 'jam'),
(112, 'Japan', 'jp', 'jpn'),
(113, 'Jersey', 'je', 'jey'),
(114, 'Jordan', 'jo', 'jor'),
(115, 'Kazakhstan', 'kz', 'kaz'),
(116, 'Kenya', 'ke', 'ken'),
(117, 'Kiribati', 'ki', 'kir'),
(118, 'Korea, Democratic People\'s Republic of', 'kp', 'prk'),
(119, 'Korea, Republic of', 'kr', 'kor'),
(120, 'Kuwait', 'kw', 'kwt'),
(121, 'Kyrgyzstan', 'kg', 'kgz'),
(122, 'Lao People\'s Democratic Republic', 'la', 'lao'),
(123, 'Latvia', 'lv', 'lva'),
(124, 'Lebanon', 'lb', 'lbn'),
(125, 'Lesotho', 'ls', 'lso'),
(126, 'Liberia', 'lr', 'lbr'),
(127, 'Libyan Arab Jamahiriya', 'ly', 'lby'),
(128, 'Liechtenstein', 'li', 'lie'),
(129, 'Lithuania', 'lt', 'ltu'),
(130, 'Luxembourg', 'lu', 'lux'),
(131, 'Macao', 'mo', 'mac'),
(132, 'Macedonia, The former Yugoslav Republic of', 'mk', 'mkd'),
(133, 'Madagascar', 'mg', 'mdg'),
(134, 'Malawi', 'mw', 'mwi'),
(135, 'Malaysia', 'my', 'mys'),
(136, 'Maldives', 'mv', 'mdv'),
(137, 'Mali', 'ml', 'mli'),
(138, 'Malta', 'mt', 'mlt'),
(139, 'Marshall Islands', 'mh', 'mhl'),
(140, 'Martinique', 'mq', 'mtq'),
(141, 'Mauritania', 'mr', 'mrt'),
(142, 'Mauritius', 'mu', 'mus'),
(143, 'Mayotte', 'yt', 'myt'),
(144, 'Mexico', 'mx', 'mex'),
(145, 'Micronesia, Federated States of', 'fm', 'fsm'),
(146, 'Moldova, Republic of', 'md', 'mda'),
(147, 'Monaco', 'mc', 'mco'),
(148, 'Mongolia', 'mn', 'mng'),
(149, 'Montenegro', 'me', 'mne'),
(150, 'Montserrat', 'ms', 'msr'),
(151, 'Morocco', 'ma', 'mar'),
(152, 'Mozambique', 'mz', 'moz'),
(153, 'Myanmar', 'mm', 'mmr'),
(154, 'Namibia', 'na', 'nam'),
(155, 'Nauru', 'nr', 'nru'),
(156, 'Nepal', 'np', 'npl'),
(157, 'Netherlands', 'nl', 'nld'),
(158, 'New Caledonia', 'nc', 'ncl'),
(159, 'New Zealand', 'nz', 'nzl'),
(160, 'Nicaragua', 'ni', 'nic'),
(161, 'Niger', 'ne', 'ner'),
(162, 'Nigeria', 'ng', 'nga'),
(163, 'Niue', 'nu', 'niu'),
(164, 'Norfolk Island', 'nf', 'nfk'),
(165, 'Northern Mariana Islands', 'mp', 'mnp'),
(166, 'Norway', 'no', 'nor'),
(167, 'Oman', 'om', 'omn'),
(168, 'Pakistan', 'pk', 'pak'),
(169, 'Palau', 'pw', 'plw'),
(170, 'Palestinian Territory, Occupied', 'ps', 'pse'),
(171, 'Panama', 'pa', 'pan'),
(172, 'Papua New Guinea', 'pg', 'png'),
(173, 'Paraguay', 'py', 'pry'),
(174, 'Peru', 'pe', 'per'),
(175, 'Philippines', 'ph', 'phl'),
(176, 'Pitcairn', 'pn', 'pcn'),
(177, 'Poland', 'pl', 'pol'),
(178, 'Portugal', 'pt', 'prt'),
(179, 'Puerto Rico', 'pr', 'pri'),
(180, 'Qatar', 'qa', 'qat'),
(181, 'Reunion', 're', 'reu'),
(182, 'Romania', 'ro', 'rou'),
(183, 'Russian Federation', 'ru', 'rus'),
(184, 'Rwanda', 'rw', 'rwa'),
(185, 'Saint Barthelemy', 'bl', 'blm'),
(186, 'Saint Helena, Ascension and Tristan Da Cunha', 'sh', 'shn'),
(187, 'Saint Kitts and Nevis', 'kn', 'kna'),
(188, 'Saint Lucia', 'lc', 'lca'),
(189, 'Saint Martin (French Part)', 'mf', 'maf'),
(190, 'Saint Pierre and Miquelon', 'pm', 'spm'),
(191, 'Saint Vincent and The Grenadines', 'vc', 'vct'),
(192, 'Samoa', 'ws', 'wsm'),
(193, 'San Marino', 'sm', 'smr'),
(194, 'Sao Tome and Principe', 'st', 'stp'),
(195, 'Saudi Arabia', 'sa', 'sau'),
(196, 'Senegal', 'sn', 'sen'),
(197, 'Serbia', 'rs', 'srb'),
(198, 'Seychelles', 'sc', 'syc'),
(199, 'Sierra Leone', 'sl', 'sle'),
(200, 'Singapore', 'sg', 'sgp'),
(201, 'Sint Maarten (Dutch Part)', 'sx', 'sxm'),
(202, 'Slovakia', 'sk', 'svk'),
(203, 'Slovenia', 'si', 'svn'),
(204, 'Solomon Islands', 'sb', 'slb'),
(205, 'Somalia', 'so', 'som'),
(206, 'South Africa', 'za', 'zaf'),
(207, 'South Georgia and The South Sandwich Islands', 'gs', ''),
(208, 'South Sudan', 'ss', 'ssd'),
(209, 'Spain', 'es', 'esp'),
(210, 'Sri Lanka', 'lk', 'lka'),
(211, 'Sudan', 'sd', 'sdn'),
(212, 'Suriname', 'sr', 'sur'),
(213, 'Svalbard and Jan Mayen', 'sj', 'sjm'),
(214, 'Swaziland', 'sz', 'swz'),
(215, 'Sweden', 'se', 'swe'),
(216, 'Switzerland', 'ch', 'che'),
(217, 'Syrian Arab Republic', 'sy', 'syr'),
(218, 'Taiwan, Province of China', 'tw', ''),
(219, 'Tajikistan', 'tj', 'tjk'),
(220, 'Tanzania, United Republic of', 'tz', 'tza'),
(221, 'Thailand', 'th', 'tha'),
(222, 'Timor-Leste', 'tl', 'tls'),
(223, 'Togo', 'tg', 'tgo'),
(224, 'Tokelau', 'tk', 'tkl'),
(225, 'Tonga', 'to', 'ton'),
(226, 'Trinidad and Tobago', 'tt', 'tto'),
(227, 'Tunisia', 'tn', 'tun'),
(228, 'Turkey', 'tr', 'tur'),
(229, 'Turkmenistan', 'tm', 'tkm'),
(230, 'Turks and Caicos Islands', 'tc', 'tca'),
(231, 'Tuvalu', 'tv', 'tuv'),
(232, 'Uganda', 'ug', 'uga'),
(233, 'Ukraine', 'ua', 'ukr'),
(234, 'United Arab Emirates', 'ae', 'are'),
(235, 'United Kingdom', 'gb', 'gbr'),
(236, 'United States', 'us', 'usa'),
(237, 'United States Minor Outlying Islands', 'um', ''),
(238, 'Uruguay', 'uy', 'ury'),
(239, 'Uzbekistan', 'uz', 'uzb'),
(240, 'Vanuatu', 'vu', 'vut'),
(241, 'Venezuela, Bolivarian Republic of', 've', 'ven'),
(242, 'Viet Nam', 'vn', 'vnm'),
(243, 'Virgin Islands, British', 'vg', 'vgb'),
(244, 'Virgin Islands, U.S.', 'vi', 'vir'),
(245, 'Wallis and Futuna', 'wf', 'wlf'),
(246, 'Western Sahara', 'eh', 'esh'),
(247, 'Yemen', 'ye', 'yem'),
(248, 'Zambia', 'zm', 'zmb'),
(249, 'Zimbabwe', 'zw', 'zwe');

-- --------------------------------------------------------

--
-- Table structure for table `beasiswa`
--

CREATE TABLE `beasiswa` (
  `ID` int(11) NOT NULL,
  `Title` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `beasiswa`
--

INSERT INTO `beasiswa` (`ID`, `Title`) VALUES
(1, 'Beasiswa Pemerintah Jawa Barat'),
(2, 'Beasiswa Pemerintah Jawa Tengah'),
(3, 'Beasiswa Pemerintah Jawa Timur'),
(4, 'Beasiswa Pemerintah Banten'),
(5, 'Beasiswa Pemerintah Jakarta'),
(6, 'Beasiswa Pemerintah Bali'),
(7, 'Beasiswa Pemerintah NTT'),
(8, 'Beasiswa Pemerintah NTB'),
(9, 'Beasiswa Pemerintah Sumatera'),
(10, 'Beasiswa Pemerintah Kalimanta'),
(11, 'Beasiswa Pemerintah Jawa Barat'),
(12, 'Beasiswa Pemerintah Jawa Tengah'),
(13, 'Beasiswa Pemerintah Jawa Timur'),
(14, 'Beasiswa Pemerintah Banten'),
(15, 'Beasiswa Pemerintah Jakarta'),
(16, 'Beasiswa Pemerintah Bali'),
(17, 'Beasiswa Pemerintah NTT'),
(18, 'Beasiswa Pemerintah NTB'),
(19, 'Beasiswa Pemerintah Sumatera'),
(20, 'Beasiswa Pemerintah Kalimanta');

-- --------------------------------------------------------

--
-- Table structure for table `berkas`
--

CREATE TABLE `berkas` (
  `ID_Pemilik` int(11) NOT NULL,
  `Namafile` varchar(50) NOT NULL,
  `Tipe` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `berkas`
--

INSERT INTO `berkas` (`ID_Pemilik`, `Namafile`, `Tipe`) VALUES
(1, '1_Legalitas_Form Ticketing Alfest 9 (Responses).xl', 'Surat Legalitas'),
(1, '1_Legalitas_Form Ticketing Alfest 9 (Responses).xl', 'Surat Legalitas'),
(1, 'Logo_1_Logo_Octocat.png', 'Logo'),
(1, '1_Legalitas_Form Ticketing Alfest 9 (Responses).xl', 'Surat Legalitas'),
(1, 'Logo_1_Logo_Octocat.png', 'Logo'),
(1, '1_Legalitas_Form Ticketing Alfest 9 (Responses).xl', 'Surat Legalitas'),
(1, 'Logo_1_Logo_Octocat.png', 'Logo'),
(1, '1_Surat Keterangan Tidak Mampu_[PUBLISH] NILAI UTS', 'Surat Keterangan Tidak Mampu'),
(1, '1_KTP_[PUBLISH] NILAI UTS PBO (2B).pdf', 'Akta'),
(1, '1_KTP_4- Generalization & specification.pptx', 'KTP'),
(1, '1_KK_8.-PENDIDIKAN-PANCASILA.pdf', 'KK');

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE `country` (
  `id` int(11) NOT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`id`, `name`, `status`) VALUES
(1, 'Afghanistan', 1),
(2, 'Albania', 1),
(3, 'Algeria', 1),
(4, 'Andorra', 1),
(5, 'Angola', 1),
(6, 'Antigua and Barbuda', 1),
(7, 'Argentina', 1),
(8, 'Armenia', 1),
(9, 'Australia', 1),
(10, 'Austria', 1),
(11, 'Azerbaijan', 1),
(12, 'Bahamas', 1),
(13, 'Bahrain', 1),
(14, 'Bangladesh', 1),
(15, 'Barbados', 1),
(16, 'Belarus', 1),
(17, 'Belgium', 1),
(18, 'Belize', 1),
(19, 'Benin', 1),
(20, 'Bhutan', 1),
(21, 'Bolivia', 1),
(22, 'Bosnia and Herzegovina', 1),
(23, 'Botswana', 1),
(24, 'Brazil', 1),
(25, 'Brunei', 1),
(26, 'Bulgaria', 1),
(27, 'Burkina Faso', 1),
(28, 'Burundi', 1),
(29, 'Cabo Verde', 1),
(30, 'Cambodia', 1),
(31, 'Cameroon', 1),
(32, 'Canada', 1),
(33, 'Central African Republic', 1),
(34, 'Chad', 1),
(35, 'Chile', 1),
(36, 'China', 1),
(37, 'Colombia', 1),
(38, 'Comoros', 1),
(39, 'Congo, Republic of the', 1),
(40, 'Congo, Democratic Republic of the', 1),
(41, 'Costa Rica', 1),
(42, 'Cote d Ivoire', 1),
(43, 'Croatia', 1),
(44, 'Cuba', 1),
(45, 'Cyprus', 1),
(46, 'Czech Republic', 1),
(47, 'Denmark', 1),
(48, 'Djibouti', 1),
(49, 'Dominica', 1),
(50, 'Dominican Republic', 1),
(51, 'Ecuador', 1),
(52, 'Egypt', 1),
(53, 'El Salvador', 1),
(54, 'Equatorial Guinea', 1),
(55, 'Eritrea', 1),
(56, 'Estonia', 1),
(57, 'Ethiopia', 1),
(58, 'Fiji', 1),
(59, 'Finland', 1),
(60, 'France', 1),
(61, 'Gabon', 1),
(62, 'Gambia', 1),
(63, 'Georgia', 1),
(64, 'Germany', 1),
(65, 'Ghana', 1),
(66, 'Greece', 1),
(67, 'Grenada', 1),
(68, 'Guatemala', 1),
(69, 'Guinea', 1),
(70, 'Guinea-Bissau', 1),
(71, 'Guyana', 1),
(72, 'Haiti', 1),
(73, 'Honduras', 1),
(74, 'Hungary', 1),
(75, 'Iceland', 1),
(76, 'India', 1),
(77, 'Indonesia', 1),
(78, 'Iran', 1),
(79, 'Iraq', 1),
(80, 'Ireland', 1),
(81, 'Italy', 1),
(82, 'Jamaica', 1),
(83, 'Japan', 1),
(84, 'Jordan', 1),
(85, 'Kazakhstan', 1),
(86, 'Kenya', 1),
(87, 'Kiribati', 1),
(88, 'Kosovo', 1),
(89, 'Kuwait', 1),
(90, 'Kyrgyzstan', 1),
(91, 'Laos', 1),
(92, 'Latvia', 1),
(93, 'Lebanon', 1),
(94, 'Lesotho', 1),
(95, 'Liberia', 1),
(96, 'Libya', 1),
(97, 'Liechtenstein', 1),
(98, 'Lithuania', 1),
(99, 'Luxembourg', 1),
(100, 'Macedonia', 1),
(101, 'Madagascar', 1),
(102, 'Malawi', 1),
(103, 'Malaysia', 1),
(104, 'Maldives', 1),
(105, 'Mali', 1),
(106, 'Malta', 1),
(107, 'Marshall Islands', 1),
(108, 'Mauritania', 1),
(109, 'Mauritius', 1),
(110, 'Mexico', 1),
(111, 'Micronesia', 1),
(112, 'Moldova', 1),
(113, 'Monaco', 1),
(114, 'Mongolia', 1),
(115, 'Montenegro', 1),
(116, 'Morocco', 1),
(117, 'Mozambique', 1),
(118, 'Myanmar (Burma)', 1),
(119, 'Namibia', 1),
(120, 'Nauru', 1),
(121, 'Nepal', 1),
(122, 'Netherlands', 1),
(123, 'New Zealand', 1),
(124, 'Nicaragua', 1),
(125, 'Niger', 1),
(126, 'Nigeria', 1),
(127, 'North Korea', 1),
(128, 'Norway', 1),
(129, 'Oman', 1),
(130, 'Pakistan', 1),
(131, 'Palau', 1),
(132, 'Palestine', 1),
(133, 'Panama', 1),
(134, 'Papua New Guinea', 1),
(135, 'Paraguay', 1),
(136, 'Peru', 1),
(137, 'Philippines', 1),
(138, 'Poland', 1),
(139, 'Portugal', 1),
(140, 'Qatar', 1),
(141, 'Romania', 1),
(142, 'Russia', 1),
(143, 'Rwanda', 1),
(144, 'St. Kitts and Nevis', 1),
(145, 'St. Lucia', 1),
(146, 'St. Vincent and The Grenadines', 1),
(147, 'Samoa', 1),
(148, 'San Marino', 1),
(149, 'Sao Tome and Principe', 1),
(150, 'Saudi Arabia', 1),
(151, 'Senegal', 1),
(152, 'Serbia', 1),
(153, 'Seychelles', 1),
(154, 'Sierra Leone', 1),
(155, 'Singapore', 1),
(156, 'Slovakia', 1),
(157, 'Slovenia', 1),
(158, 'Solomon Islands', 1),
(159, 'Somalia', 1),
(160, 'South Africa', 1),
(161, 'South Korea', 1),
(162, 'South Sudan', 1),
(163, 'Spain', 1),
(164, 'Sri Lanka', 1),
(165, 'Sudan', 1),
(166, 'Suriname', 1),
(167, 'Swaziland', 1),
(168, 'Sweden', 1),
(169, 'Switzerland', 1),
(170, 'Syria', 1),
(171, 'Taiwan', 1),
(172, 'Tajikistan', 1),
(173, 'Tanzania', 1),
(174, 'Thailand', 1),
(175, 'Timor-Leste', 1),
(176, 'Togo', 1),
(177, 'Tonga', 1),
(178, 'Trinidad and Tobago', 1),
(179, 'Tunisia', 1),
(180, 'Turkey', 1),
(181, 'Turkmenistan', 1),
(182, 'Tuvalu', 1),
(183, 'Uganda', 1),
(184, 'Ukraine', 1),
(185, 'United Arab Emirates', 1),
(186, 'United Kingdom (UK)', 1),
(187, 'United States of America (USA)', 1),
(188, 'Uruguay', 1),
(189, 'Uzbekistan', 1),
(190, 'Vanuatu', 1),
(191, 'Vatican City (Holy See)', 1),
(192, 'Venezuela', 1),
(193, 'Vietnam', 1),
(194, 'Yemen', 1),
(195, 'Zambia', 1),
(196, 'Zimbabwe', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pendaftar`
--

CREATE TABLE `pendaftar` (
  `ID_Pdaftar` int(11) NOT NULL,
  `Nama_Pdaftar` varchar(50) DEFAULT NULL,
  `Tgl_Lahir` date DEFAULT NULL,
  `Tmpt_Lahir` varchar(30) DEFAULT NULL,
  `Alamat` varchar(100) DEFAULT NULL,
  `No_HP` varchar(13) DEFAULT NULL,
  `No_Telp` varchar(20) DEFAULT NULL,
  `No_KK` varchar(13) DEFAULT NULL,
  `NIK` varchar(15) NOT NULL,
  `Pendidikan_Sedang_Berlangsung` varchar(10) NOT NULL,
  `NIM` varchar(15) NOT NULL,
  `NISN` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pendidikan`
--

CREATE TABLE `pendidikan` (
  `ID_Pdaftar` int(11) NOT NULL,
  `Nomor_Induk_Sekolah` int(11) NOT NULL,
  `Lama_Pendidikan` int(11) NOT NULL,
  `Tahun_Masuk` int(11) NOT NULL,
  `Tahun_Selesai` int(11) NOT NULL,
  `Nilai_UN` float DEFAULT NULL,
  `Nilai_US` float DEFAULT NULL,
  `IPK` float DEFAULT NULL,
  `Jurusan` varchar(25) DEFAULT NULL,
  `Jenjang` varchar(10) NOT NULL,
  `Status` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `penyelenggara`
--

CREATE TABLE `penyelenggara` (
  `ID_Penyelenggara` int(11) NOT NULL,
  `Jenis` varchar(25) NOT NULL,
  `Nama` varchar(50) NOT NULL,
  `Alamat` varchar(100) NOT NULL,
  `No_Telp` varchar(15) NOT NULL,
  `Website` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sekolah`
--

CREATE TABLE `sekolah` (
  `NPSN` varchar(15) NOT NULL,
  `Nama_Sekolah` varchar(50) NOT NULL,
  `Alamat` varchar(255) NOT NULL,
  `Kelurahan` varchar(50) NOT NULL,
  `Status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sekolah`
--

INSERT INTO `sekolah` (`NPSN`, `Nama_Sekolah`, `Alamat`, `Kelurahan`, `Status`) VALUES
('20177989', 'MAS AL-IHSAN', 'Jl.adipatiagungno.40 Rt.01 Rw.17', 'Baleendah', 'SWASTA'),
('20205053', 'SD NEGERI MUNGGANG SALUYU', 'JL SUKAMULUS NO 1', 'Cigugur Girang', 'NEGERI'),
('20205063', 'SDN MUNJUL', 'Kp.Pasarkemis', 'Manggahang', 'NEGERI'),
('20205108', 'SDN NEGLASARI', 'Jl. Neglasari No. 60 RT 09 RW 10', 'Manggahang', 'NEGERI'),
('20205137', 'SDN MARGALUYU', 'Kp. Curug', 'Wargamekar', 'NEGERI'),
('20205197', 'SDN MEKARSARI', 'JL. R.A.A. WIRANATAKUSUMAH', 'Baleendah', 'NEGERI'),
('20205205', 'SD NEGERI MEKAR RAHAYU', 'Kp. Manglayang RT.02 RW.03', 'Cihanjuang Rahayu', 'NEGERI'),
('20205268', 'SD NEGERI PANYAIRAN 01', 'Jl. Cigugur Girang No.18 RT.02 RW.02', 'Cigugur Girang', 'NEGERI'),
('20205427', 'SD NEGERI KANCAH', 'Jl. Sukawana RT.03 RW.16', 'Cihideung', 'NEGERI'),
('20205452', 'SD NEGERI JEUNGJINGRIGIL TENGAH', 'Jalan Lembur Tengah', 'Sariwangi', 'NEGERI'),
('20205453', 'SD NEGERI JEUNGJINGRIGIL 3', 'Jl Lembur Tengah', 'Sariwangi', 'NEGERI'),
('20205501', 'SD NEGERI KARYA UTAMA', 'Jln. Nyampay RT.02 RW.03', 'Karyawangi', 'NEGERI'),
('20205506', 'SD NEGERI KARYAWANGI', 'Jl. Kolonel Masturi No.288 RT.01 RW.11', 'Karyawangi', 'NEGERI'),
('20205516', 'SDN KAWUNGSARIGIRANG', 'Kp. Kawungsari Girang RT 02 RW 08', 'Wargamekar', 'NEGERI'),
('20205544', 'SD NEGERI HARAPAN MULYA', 'Jl. Karyawangi No.81 RT.01 RW.06', 'Karyawangi', 'NEGERI'),
('20205573', 'SD NEGERI HANJUANG SARI', 'Jl. Cihanjuang No.144 RT.02 RW.07', 'Cihanjuang', 'NEGERI'),
('20205579', 'SDN JELEKONG', 'Kp.jelekong', 'JELEKONG', 'NEGERI'),
('20205580', 'SDN JATISARI', 'Kp. Cimuncang', 'Manggahang', 'NEGERI'),
('20205585', 'SDN JATIMEKAR', 'Jl. Raya Andir Kp. Jatimekar', 'BOJONGMALAKA', 'NEGERI'),
('20205617', 'SDN JATI 03', 'Kp. Parunghalang Rt. 12 Rw. 01', 'ANDIR', 'NEGERI'),
('20205619', 'SDN JATI 02', 'Kp. Parunghalang', 'Andir', 'NEGERI'),
('20205621', 'SDN JATI 01', 'Kp. Parunghalang', 'ANDIR', 'NEGERI'),
('20205701', 'SDN RD. MANGKUDIKUSUMAH', 'Jl.laswi No.68', 'WARGA MEKAR', 'NEGERI'),
('20205705', 'SDN MANGGAHANG 03', 'Jl. Laswi No.157 RT. 09 RW. 05', 'Manggahang', 'NEGERI'),
('20205706', 'SDN MANGGAHANG 02', 'Jl. Raya Laswi No. 86', 'Manggahang', 'NEGERI'),
('20205707', 'SDN MANGGAHANG 01', 'Jl. Laswi No. 161', 'MANGGAHANG', 'NEGERI'),
('20205736', 'SDN KULALET 02', 'Jl.Raya Banjaran No.212', 'Andir', 'NEGERI'),
('20205737', 'SDN KULALET 01', 'Jl.raya Banjaran Km 11 No.212', 'ANDIR', 'NEGERI'),
('20205758', 'SDN KORPRI 03', 'Jl.adipatikertamanah No.59', 'BALEENDAH', 'NEGERI'),
('20205759', 'SDN KORPRI 02', 'Jl. Adipati Kertamanah No.59', 'Baleendah', 'NEGERI'),
('20205772', 'SDN KORPRI 01', 'Jl. Adipatikertamanah No.59', 'Baleendah', 'NEGERI'),
('20205907', 'SD NEGERI TUTUGAN RAHAYU', 'Jl. Cihanjuang, Kp. Tutugan RT 01 RW 06', 'Cihanjuang Rahayu', 'NEGERI'),
('20205908', 'SD NEGERI TUNAS KARYA', 'Perkebunan Sukawana RT.01 RW.12', 'Karyawangi', 'NEGERI'),
('20205923', 'SD NEGERI TUGU', 'Jl. Terusan Sersan Bajuri RT.03 RW.07', 'Cihideung', 'NEGERI'),
('20205956', 'SDN SUKAMULYA', 'Kp. Rancamanuk Rt. 03 Rw. 13', 'Wargamekar', 'NEGERI'),
('20205971', 'SD NEGERI SUKAMULYA', 'Jl. Sukamulya RT.02 RW.04', 'Cihideung', 'NEGERI'),
('20206023', 'SD NEGERI SUKASIRNA', 'Jl. Terusan Sersan Bajuri No.34', 'Cihideung', 'NEGERI'),
('20206077', 'SMPN 1 BALEENDAH', 'Jl. Adipati Agung No. 29', 'BALEENDAH', 'NEGERI'),
('20206114', 'SMP NEGERI 1 PARONGPONG', 'Jl. Cihanjuang No. 40', 'Cihanjuang Rahayu', 'NEGERI'),
('20206126', 'SMPN 2 BALEENDAH', 'Jln Siliwangi', 'Baleendah', 'NEGERI'),
('20206151', 'SMAN 1 BALEENDAH', 'JL. RAA. WIRANATAKUSUMAH NO. 30 BALEENDAH', 'Baleendah', 'NEGERI'),
('20206183', 'SMP KP 1 BALEENDAH', 'Jl. Adipati Agung No. 32', 'BALEENDAH', 'SWASTA'),
('20206225', 'SMKN 3 BALEENDAH', 'JL. Adipati Agung No. 34 Baleendah', 'Baleendah', 'NEGERI'),
('20206226', 'SMKN 2 BALEENDAH', 'JL. RAA WIRANATAKUSUMAH NO. 11', 'Baleendah', 'NEGERI'),
('20206300', 'SDN RIUNGGUNUNG', 'Jl. Cimuncang', 'Manggahang', 'NEGERI'),
('20206305', 'SDN RANCAMANYAR 03', 'Jl.cilebak', 'Rancamanyar', 'NEGERI'),
('20206306', 'SDN RANCAMANYAR 02', 'Jl. Raya Penclut No.26', 'Rancamanyar', 'NEGERI'),
('20206307', 'SDN RANCAMANYAR 01', 'Kp.Bojongkukun', 'RANCAMANYAR', 'NEGERI'),
('20206323', 'SDN RANCAPANJANG', 'Kp.babakan', 'RANCAMANYAR', 'NEGERI'),
('20206337', 'SDN PASIRPAROS', 'Jl.kiastramanggala Rt 03 Rw 12', 'BALEENDAH', 'NEGERI'),
('20206510', 'SD NEGERI SUKAHURIP', 'Jl. Cigugurgirang RT.01 RW.03', 'Cigugur Girang', 'NEGERI'),
('20206520', 'SDN SUKAJADI', 'Kp. Sukajadi', 'Jelekong', 'NEGERI'),
('20206562', 'SDN SARIMALAKA', 'Kp.pameutingan', 'MALAKASARI', 'NEGERI'),
('20206594', 'SDN SIPATAHUNAN', 'Jl. Mekarsari No.03', 'BALEENDAH', 'NEGERI'),
('20206617', 'SDN SINDANGSARI', 'Kp.Sindangsari', 'Manggahang', 'NEGERI'),
('20206633', 'SD MUHAMMADIYAH 4', 'Jl. Purawijaya No 19', 'Bojongmalaka', 'SWASTA'),
('20206635', 'SDN ANDIR 01', 'Kp. Jambatan', 'Andir', 'NEGERI'),
('20206644', 'SDN ANDIR 02', 'Kp. Sukamelang', 'ANDIR', 'NEGERI'),
('20206839', 'SDN BOJONGMALAKA 01', 'Bojongmalaka', 'Bojongmalaka', 'NEGERI'),
('20206866', 'SDN BOJONGMALAKA 02', 'Bojongmalaka', 'BOJONGMALAKA', 'NEGERI'),
('20206895', 'SD NEGERI BUDHI KARYA', 'Jl. Waruga Jaya RT.04 RW.11', 'Ciwaruga', 'NEGERI'),
('20206908', 'SDN BUKITMULYA', 'Kp. Bukitmulya', 'MANGGAHANG', 'NEGERI'),
('20206967', 'SDN BALEENDAH 04', 'Jl.situsipatahunan', 'BALEENDAH', 'NEGERI'),
('20206969', 'SDN BALEENDAH 02', 'Jl.situsipatahunan', 'BALEENDAH', 'NEGERI'),
('20206970', 'SDN BALEENDAH 01', 'Baleendah Rt 05 Rw 05', 'BALEENDAH', 'NEGERI'),
('20207488', 'SDN CIPTAWINAYA', 'Jl. Terusan Siliwangi No.47 Cipicung', 'Manggahang', 'NEGERI'),
('20207503', 'SDN CIPTAKARYA', 'Kp.Cipicung Rt 08 Rw 02', 'Baleendah', 'NEGERI'),
('20207598', 'SDN CIODENG', 'Jl.terusan Andir', 'BOJONGMALAKA', 'NEGERI'),
('20207607', 'SDN CIMUNCANG', 'Kp. Cimuncang', 'Manggahang', 'NEGERI'),
('20207631', 'SDN GALIHPAWARTI', 'Jl. Kujang No.24', 'Baleendah', 'NEGERI'),
('20207718', 'SDN GIRIMEKAR', 'Kp. Gugunungan', 'Jelekong', 'NEGERI'),
('20207722', 'SDN GIRIHARJA', 'Kp.giriharja', 'JELEKONG', 'NEGERI'),
('20207780', 'SD NEGERI CISINTOK', 'Jl. Cihajuang No.131 RT.01 RW.03', 'Cihanjuang', 'NEGERI'),
('20207811', 'SD NEGERI CIWARUGA 2', 'Jl. Waruga Jaya No.45 RT.03 RW.07', 'Ciwaruga', 'NEGERI'),
('20207812', 'SD NEGERI CIWARUGA 1', 'Jl. Waruga Jaya No.09 RT.03 RW.03', 'Ciwaruga', 'NEGERI'),
('20207956', 'SD NEGERI CARINGIN', 'Jl. Terusan Sersan Bajuri No.95', 'Cihideung', 'NEGERI'),
('20207982', 'SDN CANGKRING 05', 'Jl. Laswi No.305', 'WARGA MEKAR', 'NEGERI'),
('20207983', 'SDN CANGKRING 04', 'Jl. Raya Laswi No. 251 RT 02 RW 15', 'Jelekong', 'NEGERI'),
('20207984', 'SDN CANGKRING 03', 'Kp.ciparia', 'WARGA MEKAR', 'NEGERI'),
('20207986', 'SDN CANGKRING 02', 'Jl. Laswi No.305', 'Wargamekar', 'NEGERI'),
('20207987', 'SDN CANGKRING 01', 'Kp. Nangerang', 'JELEKONG', 'NEGERI'),
('20208031', 'SDN CIBADAK 03', 'Jl. Cibadak', 'ANDIR', 'NEGERI'),
('20208032', 'SDN CIBADAK 02', 'Jl. Cibadak', 'ANDIR', 'NEGERI'),
('20208034', 'SDN CIBADAK 01', 'Kp. Cibadak', 'ANDIR', 'NEGERI'),
('20208155', 'SD NEGERI CIHANJUANG 4', 'Jl. Cihanjuang Rahayu', 'Cihanjuang Rahayu', 'NEGERI'),
('20208158', 'SD NEGERI CIHANJUANG 2', 'Jl. Cihanjuang Kampung Babakan', 'Cihanjuang Rahayu', 'NEGERI'),
('20208160', 'SD NEGERI CIHANJUANG 1', 'Jl. Cihanjuang RT.02 RW.07', 'Cihanjuang', 'NEGERI'),
('20208164', 'SD NEGERI CIGUGUR GIRANG 01', 'Jl. Ditasaraya No.2 RT.01 RW.05', 'Cigugur Girang', 'NEGERI'),
('20208226', 'SD NEGERI CIHIDEUNG 01', 'Jl. Terusan Sersan Bajuri No.34', 'Cihideung', 'NEGERI'),
('20219235', 'SMAN 17 BANDUNG', 'JL. Tujuhbelas Caringin', 'Babakan Ciparay', 'NEGERI'),
('20219343', 'SMP NEGERI 21', 'Jl. Caringin Gg. Lumbung II', 'BABAKAN CIPARAY', 'NEGERI'),
('20219417', 'SMP NEGERI 39', 'Jl. Holis No.439', 'BABAKAN', 'NEGERI'),
('20219419', 'SMP NEGERI 36', 'Jl. Caringin', 'BABAKAN', 'NEGERI'),
('20219496', 'SMP PASUNDAN 9', 'Jl. Babakan Ciparay', 'Sukahaji', 'SWASTA'),
('20219504', 'SMP MUTIARA 3', 'Jl. Caringin Gg. Lumbung Ii No. 19', 'Babakan Ciparay', 'SWASTA'),
('20219528', 'SD AL BAROKAH', 'Jl. Aki Padma No. 23', 'BABAKAN', 'SWASTA'),
('20219602', 'SD CAHAYA PELITA 2', 'Jl. Babakan Ciparay', 'SUKAHAJI', 'SWASTA'),
('20219603', 'SD CAHAYA PELITA', 'Jl. Babakan Ciparay No. 251/194 A', 'Sukahaji', 'SWASTA'),
('20219815', 'SD PASUNDAN 3', 'Jl. Babakan Ciparay No.112/194 A', 'Sukahaji', 'SWASTA'),
('20219816', 'SD PASUNDAN 2', 'Jl. Babakan Ciparay No. 112 / 194 A', 'Sukahaji', 'SWASTA'),
('20219819', 'SD PANGKALAN', 'Jl. Cibolerang No. 02', 'Margahayu Utara', 'SWASTA'),
('20219826', 'SD SALUYU', 'Kp. Situgunting No. 309/194 A', 'SUKAHAJI', 'SWASTA'),
('20227510', 'SD ADVENT PARONGPONG', 'Jl. Kolonel Masturi Km 6,5 RT. 01 RW.14', 'Cihanjuang Rahayu', 'SWASTA'),
('20227515', 'SDN BALEENDAH', 'Jl. Situ Sipatahunan RT 05 RW 05', 'BALEENDAH', 'NEGERI'),
('20227544', 'SD MUTIARA NUSANTARA', 'Jl. Sersan Bajuri Km 1,5 RT.03 RW.01 Sukabaru Bandung Barat', 'Cihideung', 'SWASTA'),
('20227553', 'SD NEGERI PASIRMUNCANG', 'Jl. Raya Cigugur Girang No. 234 Kp. Pangsor RT 03 RW 07', 'Cigugur Girang', 'NEGERI'),
('20227585', 'SD INDRIYASANA', 'Jl.Laswi No.56 B Baleendah', 'Baleendah', 'SWASTA'),
('20227627', 'SMP AL QONA AH', 'Jl. Giriharja No.41', 'JELEKONG', 'SWASTA'),
('20227637', 'SMP BPPI BALEENDAH', 'Jl. Adipati Agung No. 23', 'Baleendah', 'SWASTA'),
('20227646', 'SMP BINA NEGARA 2', 'Jln. Raya Andir No.216 Rt.10 Rw.03', 'Andir', 'SWASTA'),
('20227698', 'SMP MUHAMMADIYAH 6 BALEENDAH', 'Jl. Mitra No. 171 Bojongmalaka', 'Bojongmalaka', 'SWASTA'),
('20227707', 'SMP MUTIARA SANDI', 'Jl. Raya Laswi No. 345', 'Manggahang', 'SWASTA'),
('20227722', 'SMP PGRI BALEENDAH', 'Jl. Tpa Wagamekar', 'WARGAMEKAR', 'SWASTA'),
('20227752', 'SMP STMC 4245 BALEENDAH', 'Jl Adikusumah N0. 26', 'BALEENDAH', 'SWASTA'),
('20227791', 'SMP YPPI BALEENDAH', 'Jl. Situ Sipatahunan No. 09', 'Baleendah', 'SWASTA'),
('20227799', 'SMP AMAL KELUARGA', 'Jl. Cigugur Girang', 'Cigugur Girang', 'SWASTA'),
('20227826', 'SMA BPPI BALEENDAH', 'JL. ADIPATI AGUNG NO.23', 'Baleendah', 'SWASTA'),
('20227830', 'SMA BINA NEGARA 1 BALEENDAH', 'JL. RAYA ANDIR NO.216 BALEENDAH', 'Andir', 'SWASTA'),
('20227839', 'SMAS HARAPAN BANGSA BALEENDAH', 'JL. PURADINATA NO. D19 BALEENDAH', 'Baleendah', 'SWASTA'),
('20227901', 'SMAN 1 PARONGPONG', 'Jl. Cihanjuang Rahayu No.39', 'Cihanjuang Rahayu', 'NEGERI'),
('20227949', 'SMK KP BALEENDAH', 'JL. ADIPATI AGUNG NO. 32 BALEENDAH', 'Baleendah', 'SWASTA'),
('20227960', 'SMK MUTIARA SANDI BALEENDAH', 'JL. LASWI NO. 345 MANGGAHANG BALEENDAH', 'Manggahang', 'SWASTA'),
('20227965', 'SMK STMC 4245 BALEENDAH', 'JL. ADIKUSUMAH NO. 26 BALEENDAH', 'Baleendah', 'SWASTA'),
('20228118', 'SD AL-MABRUR', 'Jl.Patrol V Kavling 2 - 4', 'BALEENDAH', 'SWASTA'),
('20228142', 'SDN KAWUNGSARI', 'Kp.kawungsari', 'WARGA MEKAR', 'NEGERI'),
('20228149', 'SDN MALAKASARI', 'Kp. Bojongcibodas Baleendah', 'Malakasari', 'NEGERI'),
('20228171', 'SDN RANCAMANYAR 06', 'Jl. Raya Penclut', 'RANCAMANYAR', 'NEGERI'),
('20228186', 'SD DAARUL FIKRI', 'Komplek Cibaligo Permai, Jl. Daarul Fikri No. 02 RT.06 RW.02', 'Cihanjuang', 'SWASTA'),
('20228189', 'SD KARTIKA XI-12', 'Jl. Kol. Masturi RT.03 RW.11 Ds. Karyawangi Parongpong', 'Karyawangi', 'SWASTA'),
('20228442', 'SMA KP BALEENDAH', 'JL.ADIPATI AGUNG NO.32 BALEENDAH', 'Baleendah', 'SWASTA'),
('20228467', 'SMA MUTIARA SANDI', 'JL. LASWI NO 345 MANGGAHANG BALEENDAH', 'Manggahang', 'SWASTA'),
('20229784', 'SMKN 7 BALEENDAH', 'JL. SILIWANGI KM 15 RT 08 RW 14', 'Manggahang', 'NEGERI'),
('20229809', 'SMP MUTIARA NUSANTARA', 'Jl. Sersan Bajuri Km 1,5 RT 01 / RW 02, kampung sukabaru', 'Cihideung', 'SWASTA'),
('20229822', 'SMK BINA NEGARA BALEENDAH', 'JALAN RAYA ANDIR NO.216 BALEENDAH', 'Andir', 'SWASTA'),
('20244995', 'SDN 126 BABAKAN KOTA BANDUNG', 'Jl. Aki Padma No. 1', 'Babakan', 'NEGERI'),
('20244998', 'SDN 089 BABAKAN CIPARAY KOTA BANDUNG', 'Jl. Caringin No. 150', 'Babakan Ciparay', 'NEGERI'),
('20245001', 'SDN 236 BABAKAN CIPARAY KOTA BANDUNG', 'Jl. Caringin Gg. Lumbung III No. 50', 'Babakan Ciparay', 'NEGERI'),
('20245008', 'SDN 213 BABAKAN CIPARAY KOTA BANDUNG', 'Jl. Caringin Cikungkurak RT.03/06', 'Babakan Ciparay', 'NEGERI'),
('20245011', 'SDN 005 BABAKAN CIPARAY KOTA BANDUNG', 'Jl. Kopo No. 440', 'Babakan Ciparay', 'NEGERI'),
('20245013', 'SDN 012 BABAKAN CIPARAY KOTA BANDUNG', 'Jl. Caringin No.106', 'Babakan Ciparay', 'NEGERI'),
('20245014', 'SDN 058 BABAKAN CIPARAY KOTA BANDUNG', 'Jl. Caringin Gg. Porib 3', 'Babakan Ciparay', 'NEGERI'),
('20245025', 'SDN 059 CIRANGRANG KOTA BANDUNG', 'Jl. K.H. Wahid Hasyim Kopo Km 5,5', 'Margasuka', 'NEGERI'),
('20245044', 'SDN 237 KOPO ELOK KOTA BANDUNG', 'Jl. Buana No. 8', 'Cirangrang', 'NEGERI'),
('20245046', 'SDN 227 MARGAHAYU UTARA KOTA BANDUNG', 'Jl. Cibolerang No. 185', 'Margasuka', 'NEGERI'),
('20245078', 'SDN 060 RAYA BARAT KOTA BANDUNG', 'Jl. Jendral Sudirman No. 587', 'Sukahaji', 'NEGERI'),
('20245089', 'SDN 144 SITUGUNTING KOTA BANDUNG', 'Jl. H. Zakaria No. 56', 'Sukahaji', 'NEGERI'),
('20245090', 'SDN 245 SUMBERSARI INDAH KOTA BANDUNG', 'Jl. Sumber Makmur No. 1', 'Babakan', 'NEGERI'),
('20251790', 'SMA YPPI BALEENDAH', 'JL. SITU SIPATAHUNAN NO. 09 BALEENDAH', 'Baleendah', 'SWASTA'),
('20252437', 'SD AR-RAFI DRAJAT', 'Jl. Raya Banjaran No.173 A Km.12', 'Andir', 'SWASTA'),
('20252481', 'SMP PLUS AL ISTIQOMAH', 'Jl. Laswi Cipeuteuy-Baleendah Rt. 01/04', 'Baleendah', 'SWASTA'),
('20252491', 'SMP GEMAH BALEENDAH', 'Jl. Laswi Giriharja No. 3 RT. 01 RW. 03', 'Jelekong', 'SWASTA'),
('20252494', 'SMP KP 2 BALEENDAH', 'Jl. Raya Andir Ciodeng Timur No. 50a', 'Bojongmalaka', 'SWASTA'),
('20252543', 'SMPN 3 BALEENDAH', 'Jln. Rancamanyar', 'Rancamanyar', 'NEGERI'),
('20252580', 'SMP ADVENT PARONGPONG', 'Jl. Kol.masturi Km 6,5', 'Cihanjuang Rahayu', 'SWASTA'),
('20252582', 'SMP DARUL HIKMAH', 'Jln Sariwangi No. 81', 'Sariwangi', 'SWASTA'),
('20252885', 'SMP HARAPAN BANGSA', 'Jl.puradinata No.66', 'BALEENDAH', 'SWASTA'),
('20253960', 'SMK WIDYA UTAMA', 'JL. ADIPATI AGUNG NO. 2', 'Baleendah', 'SWASTA'),
('20254133', 'SMK PUTRA BAHARI', 'JL . JATIMEKAR RT 03 RW 06', 'Bojongmalaka', 'SWASTA'),
('20254184', 'SDIT FITHRAH INSANI 2', 'Jl.Laswi No. 177A', 'Manggahang', 'SWASTA'),
('20256563', 'SMK HARAPAN BANGSA BALEENDAH', 'JL. PURADINATA D.9 BALEENDAH', 'Baleendah', 'SWASTA'),
('20256637', 'SMA AL-QONAAH BALEENDAH', 'JL. GIRI HARJA NO. 41', 'Jelekong', 'SWASTA'),
('20258101', 'SD NEGERI SARIWANGI', 'Jl.Sariwangi Raya No.129A RT.05 RW.09', 'Sariwangi', 'NEGERI'),
('20258189', 'SD INTERAKTIF ABDUSSALAM', 'Jl. Cihanjuang Cibaligo No.17 RT.10 RW.01', 'Cihanjuang', 'SWASTA'),
('20259576', 'SMK BPPI BALEENDAH', 'JL. ADIPATI AGUNG N0. 23', 'Baleendah', 'SWASTA'),
('20267599', 'SD NEGERI HANJUANG SAMIJAYA', 'Jl. Cihanjuang - Cibaligo RT.04 RW.14', 'Cihanjuang', 'NEGERI'),
('20267606', 'SD AMAL KELUARGA', 'Jl. Cigugur Girang No.297 RT.04 RW.05', 'Cigugur Girang', 'SWASTA'),
('20267643', 'SMKS BINNA ESSA', 'JL CIHANJUANG 2,45', 'Cihanjuang', 'SWASTA'),
('20269142', 'SMP RANCAMANYAR', 'RANCAMANYAR', 'RANCAMANYAR', 'SWASTA'),
('20271615', 'SMP ISLAM TERPADU DAARUL FIKRI', 'Komp. Cibaligo Permai Jl. Daarul Fikri No. 2', 'Cihanjuang', 'SWASTA'),
('20278051', 'MTSS AL-IHSAN', 'Jl. Adipati Agung No.40 Rt. 01 Rw. 17', '-', 'SWASTA'),
('20278052', 'MTSS AS-SALAM', 'Kp. Rancamanuk Rt.01/13', '-', 'SWASTA'),
('20278053', 'MTSS YPBS BAITUL IKHLAS', 'Jl Anggadireja Kp. Mulyasari', '-', 'SWASTA'),
('20278060', 'MTSS AS-SOLEHHIYAH', 'Kp. Mekarsari Rt.01/23', '-', 'SWASTA'),
('20279482', 'MTSS AZ-ZAHRA PARONGPONG', 'CIHANJUANG KM 8,2 KP. PANEUNGTEUNN', 'CIHANJUANG RAHAYU', 'SWASTA'),
('20279483', 'MTSS CISASAWI', 'KP. CISASAWI RT.02 RW.06', '-', 'SWASTA'),
('20279556', 'MTSN BANDUNG', 'JL. TERUSAN HOLIS BABAKAN CIPARAY BANDUNG', 'Margahayu Utara', 'NEGERI'),
('20279557', 'MTSS AL AMANAH', 'JL. SUMBER SUGIH NO.8', 'Babakan', 'SWASTA'),
('20279857', 'SMP NEGERI 3 PARONGPONG', 'JL. DESA KARYAWANGI NO.13', 'Karyawangi', 'NEGERI'),
('20279863', 'SMP NEGERI 2 PARONGPONG', 'Jl. Warugajaya No.13 Kp. Cibadak RT.03 RW.15', 'Ciwaruga', 'NEGERI'),
('20280023', 'MAS AZ-ZAHRA', 'JL. CIHANJUANG KM 8,2 RT 02 RW 16', '-', 'SWASTA'),
('60707717', 'MIS AL-HIDAYAH', 'Jl. Mulyasari RT 01/19', '-', 'SWASTA'),
('60707718', 'MIS BAITUL HUDA', 'Jl. H. Mulya Kp. Mekarsari Rt. 02/09', '-', 'SWASTA'),
('60707719', 'MIS PERSIS NO. 8 PAMEUTINGAN', 'Kp. Pameutingan RT. 01 RW. 09 Kec. Baleendah Kab. Bandung', '-', 'SWASTA'),
('60709596', 'MIS CISASAWI', 'KP. CISASAWI RT 02/06', '-', 'SWASTA'),
('60709597', 'MIS JEUNGJINGRIGIL', 'JL. MEKARWANGI RT. 02/12', '-', 'SWASTA'),
('60709598', 'MIS NURUL HUDA CIWARUGA', 'JL. WARUGAJAYA NO 104 RT. 04 RW. 11 DES. CIWARUGA KEC. PARONGPONG KAB. BANDUNG', '-', 'SWASTA'),
('60709707', 'MIS AL BAROKAH', 'JL. AKI PADMA NO.23', '-', 'SWASTA'),
('60709708', 'MIS AL FURQON I', 'JL. PAGARSIH BARAT GG.MADRASAH NO.503 RT.02 RW.01', '-', 'SWASTA'),
('60709709', 'MIS AL FURQON II', 'JL. TERUSAN PASIR KOJA GG.SATATASARIKSA NO.388/194A RT.06 RW.03', '-', 'SWASTA'),
('60709710', 'MIS AR ROHMAH', 'JL. SOEKARNO HATTA GG.HASAN BLOK I AGER SARI NO.18 RT.02 RW.11', '-', 'SWASTA'),
('60709711', 'MIS DARUL QALAM', 'JL. TERUSAN HOLIS CIBOLERANG', 'Margahayu Utara', 'SWASTA'),
('60709712', 'MIS DARUSSALAM', 'JL. CARINGIN 77/192C', 'Babakan Ciparay', 'SWASTA'),
('60726650', 'SMP IT FITHRAH INSANI', 'JL. LASWI NO. 177 B', 'Manggahang', 'SWASTA'),
('60726907', 'MIS MODERN GENERASI BRILLIAN', 'JL. CIHANJUANG - GG. APIT NO. 72 CIBALIGO RT. 03 RW. 01', '-', 'SWASTA'),
('60727356', 'MTSS MATHLAUL HUDA', 'Jl. Cimuncang No.01 Pasarkemis', '-', 'SWASTA'),
('60728040', 'MAS AS-SALAM BALEENDAH', 'Kp. Rancamanuk Rt.01 Rw.13', '-', 'SWASTA'),
('60728041', 'MAS MATHLAUL HUDA', 'Jl. Cimuncang No. 01 Pasarkemis Rt. 01/14', '-', 'SWASTA'),
('60730352', 'SD UNGGULAN NASYWA', 'Jl. Lembah Permai RT.01 RW.05', 'Sariwangi', 'SWASTA'),
('60730353', 'SD FIRDAUS PERCIKAN IMAN', 'Jl. Bukit Firdaus No.9 Komp. Geger Kalong Permai RT.07 RW.07', 'Ciwaruga', 'SWASTA'),
('69733997', 'SMKS PERJUANGAN', 'Jln. Cihanjuang Rahayu No. 94', 'Cihanjuang Rahayu', 'SWASTA'),
('69766194', 'SMKS INSAN MANDIRI', 'JL SARIWANGI NO 81', 'SARIWANGI', 'SWASTA'),
('69820637', 'SMK AKAR ILMU', 'Jl. Mekar Sari No 345 RT.07/23', 'Manggahang', 'SWASTA'),
('69857715', 'SMK ISLAM PARONGPONG', 'KP. NYAMPAI NO.5 RT.02 RW.03', 'Karyawangi', 'SWASTA'),
('69886327', 'MIS Plus Kharisma Nusantara', 'Baleendah', '-', 'SWASTA'),
('69893110', 'SMA DAARUT TAUHIID BOARDING SCHOOL', 'Jalan Cigugur Girang No.33 RT.03 RW.07', 'Cigugur Girang', 'SWASTA'),
('69918870', 'SD IT MADINATUL ULUM', 'JL. KARYAWANGINO.69 RT.01 RW.05', 'Karyawangi', 'SWASTA'),
('69930027', 'SMA Mutiara Nusantara', 'Jl. Sersan Bajuri Km. 1,5 - RT 3/RW 1', 'Cihideung', 'SWASTA'),
('69943091', 'SMP IT NURUL IMAM', 'JL. CIHANJUANG KP. CISINTOK RT.04 RW.04', 'Cihanjuang', 'SWASTA'),
('69954834', 'SD IT BHAKTI PERTIWI', 'JL. MEKARSARI RT 06 RW 22', 'Baleendah', 'SWASTA'),
('69955528', 'SD WIDURI', 'Jl. Adikusumah Balesarakan RT 01/17', 'Baleendah', 'SWASTA'),
('69955685', 'Sekolah Cinta Ilmu', 'Jl. Raya Laswi No.316, Kawungsari Hilir Rt 03/11', '-', 'SWASTA'),
('69955910', 'Sekolah Cinta Ilmu', 'Jl. Raya Laswi No.316, Kp. Kawungsari Rt 03/11', '-', 'SWASTA'),
('69955911', 'An-Nur', 'Kp. Sindang Sari Rt.07 Rw.15', '-', 'SWASTA'),
('69955912', 'Kharisma Nusantara', 'Jl. Raya Andir No.216 Rt.10 Rw.3', '-', 'SWASTA'),
('69956144', 'Sekolah Cinta Ilmu', 'Jl. Laswi No.316, Kawungsari Hilir', '-', 'SWASTA'),
('69956145', 'An-Na iim', 'Jl. Cilebak', '-', 'SWASTA'),
('69959505', 'SMP DAARUT TAUHIID BOARDING SCHOOL', 'Jl. Cigugur Girang No.33 Kp. Pangsor', 'Cigugur Girang', 'SWASTA'),
('69965773', 'SMP ROUDLOTUL ULUM', 'Jl. Cisasawi RT.01 RW.06', 'Cihanjuang', 'SWASTA'),
('69965932', 'SD FUN KIDS', 'JL. PERUM PURI BUDI ASRI BLOK C NO.6-7', 'Cihanjuang', 'SWASTA'),
('69966325', 'SMP IT MADINATUL ULUM', 'Jl. Karyawangi No.69 RT.01 RW.05', 'Karyawangi', 'SWASTA'),
('69968271', 'SD AL-AMANAH', 'Jl. Prima Raya III C.15 No. 3', 'Bojongmalaka', 'SWASTA'),
('69973148', 'SD IT AZ-ZAHRA', 'Kp. Bojong Sayang RT 03 RW 4', 'Rancamanyar', 'SWASTA'),
('69973316', 'SD IT USWATUN HASANAH', 'Jl. Raya Laswi Cipicung RT 03/03', 'Manggahang', 'SWASTA'),
('NP762615', 'SMK KESEHATAN RAJAWALI', 'Jalan Cihanjuang Rahayu No. 303 Rt 01/06', 'Cihanjuang Rahayu', 'SWASTA'),
('P9962758', 'SKB UPT KOTA BANDUNG', 'Jl. Makam Caringin No. 43', 'Margahayu Utara', 'NEGERI'),
('P9963174', 'SKB KAB. BANDUNG', 'Jln. Wiranatakusumah No. 25', 'Baleendah', 'NEGERI');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `role` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password`, `created_at`, `status`, `role`) VALUES
(1, 'Super', 'admin@admin.com', '21232f297a57a5a743894a0e4a801fc3', '2018-03-02 14:51:38', 0, 'admin'),
(11, 'John ', 'user@mail.com', 'ee11cbb19052e40b07aac0ca060c23ee', '2018-03-04 23:31:53', 0, 'user'),
(14, 'Ali Piqri Sopandi', 'alipiqri2@gmail.com', 'c5c0ff95ace65441aa487d348e04a273', '2018-11-04 22:21:53', 0, 'pendaftar'),
(15, 'Ali Piqri Sopandi', 'alipiqri2@gmail.com', 'c5c0ff95ace65441aa487d348e04a273', '2018-11-04 22:31:48', 0, 'pendaftar'),
(16, 'Ali', 'a@a.com', 'c5c0ff95ace65441aa487d348e04a273', '2018-11-04 22:33:33', 0, 'pendaftar'),
(17, 'Alyy', 'alyy@gmail.com', 'dd4614f5ae4ecfe5d55abe6f27d0ef13', '2018-11-09 13:30:41', 0, 'pendaftar'),
(18, 'Lyy', 'Lyy@gmail.com', '5af3af95cdd5e92477111256a1170cd7', '2018-11-09 13:31:58', 0, 'pendaftar');

-- --------------------------------------------------------

--
-- Table structure for table `user_power`
--

CREATE TABLE `user_power` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `power_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_power`
--

INSERT INTO `user_power` (`id`, `name`, `power_id`) VALUES
(1, 'add', 1),
(2, 'edit', 2),
(3, 'delete', 3);

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE `user_role` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`id`, `user_id`, `action`) VALUES
(1, 11, 1),
(2, 11, 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `autocomplete`
--
ALTER TABLE `autocomplete`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `beasiswa`
--
ALTER TABLE `beasiswa`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pendaftar`
--
ALTER TABLE `pendaftar`
  ADD PRIMARY KEY (`ID_Pdaftar`);

--
-- Indexes for table `pendidikan`
--
ALTER TABLE `pendidikan`
  ADD PRIMARY KEY (`ID_Pdaftar`,`Nomor_Induk_Sekolah`);

--
-- Indexes for table `penyelenggara`
--
ALTER TABLE `penyelenggara`
  ADD PRIMARY KEY (`ID_Penyelenggara`);

--
-- Indexes for table `sekolah`
--
ALTER TABLE `sekolah`
  ADD PRIMARY KEY (`NPSN`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_power`
--
ALTER TABLE `user_power`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `autocomplete`
--
ALTER TABLE `autocomplete`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=250;
--
-- AUTO_INCREMENT for table `beasiswa`
--
ALTER TABLE `beasiswa`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `country`
--
ALTER TABLE `country`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=197;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `user_power`
--
ALTER TABLE `user_power`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `user_role`
--
ALTER TABLE `user_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
