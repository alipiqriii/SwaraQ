
<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->

<div class="container-fluid">

    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->

    <div class="row page-titles">
        <div class="col-md-5 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">SwaraQ Event</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active"><?php echo $page_title?></li>
            </ol>
        </div>
    </div>
    
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <!-- <div class="row">
        <div class="col-md-12">
            <iframe src="http://localhost:8080" width="100%" height="800px" id="tolltip" src="tooltip.html" width="200" height="300" scrolling="no" style="overflow:hidden;">
              <p>Your browser does not support iframes.</p>
            </iframe>
        </div>
    </div> -->
    <div class="row">
        <div class="col-12">
           <div id="accordion" class="nav-accordion" role="tablist" aria-multiselectable="true">
                <div id="accordion" class="nav-accordion" role="tablist" aria-multiselectable="true">

                <form name="form" method="post" enctype="multipart/form-data">
                <div class="row justify-content-md-center">
                    <div class="col-md-10">
                        <div class="card card-outline-info">
                            <div class="card-header" role="tab" id="headingOne">
                                <h5 class="mb-0">
                                    <a class="text-white " data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                      Data Event Pemilihan
                                    </a>
                                </h5> 
                            </div>

                            <!-- <form name="form" method="post">   -->
                            <div id="collapseOne" class="collapse show" role="tabpanel" aria-labelledby="headingOne">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <h5>Tipe Event Pemilihan<span class="text-danger">*</span></h5>
                                            <div class="form-group">
                                                <select name="tipe_pemilihan" class="form-control custom-select" data-placeholder="Tipe Event Pemilihan" tabindex="1">
                                                    <option value="Pilpres">Pemilihan Presiden</option>
                                                    <option value="Pilgub">Pemilihan Gubernur</option>
                                                    <option value="Pilkada">Pemilihan Kepala Daerah</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <h5>Lokasi<span class="text-danger">*</span></h5>
                                                <div class="controls">
                                                    <input type="text" name="lokasi" class="form-control"  data-validation-required-message="This field is required" minlength="3" aria-invalid="false"> <div class="help-block"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <h5>Tahun Pemilihan<span class="text-danger">*</span></h5>
                                                <input type="number" name="tahun_pemilihan" class="form-control"  data-validation-required-message="This field is required" minlength="4" maxlength="15" aria-invalid="false">
                                            </div>
                                        </div>
                                    </div>
                                    <!-- <div class="row">
                                        <div class="col-md-12">
                                            <input onclick="javascript: form.action='<?php echo base_url()?>Pendaftaran/addEvent';" class="btn btn-info " type="submit"/>
                                            <input type="hidden" name="<?=$this->security->get_csrf_token_name();?>" value="<?=$this->security->get_csrf_hash();?>" />
                                        </div>
                                    </div> -->
                                </div>
                            </div>
                            <!-- </form> -->

                        </div>
                    </div>
                </div>
                <div class="row justify-content-md-center">
                    <div class="col-md-10">
                        <div class="card card-outline-info">
                            <div class="card-header" role="tab" id="headingTwo">
                                <h5 class="mb-0">
                                    <a class="text-white collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                                      Data Pasangan Calon
                                    </a>
                                </h5> 
                            </div>
                            
                            <div id="collapseTwo" class="collapse show" role="tabpanel" aria-labelledby="headingTwo">
                                <div class="card-body"> 
                                    <!-- <form method="post" name="pendidikan"> -->
                                        
                                        <div id="Accordion_Paslon">
                                            <div id="Paslon_Form" class="well">
                                                <div class="card card-outline-info">
                                                    <div class="card-header">
                                                        <h5 class="mb-0 text-white ">Pasangan Calon 1</h5> 
                                                    </div>
                                                    <div class="card-body">
                                                        
                                                        <h5>Nomor Pasangan<span class="text-danger">*</span></h5>
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="form-group">
                                                                <div class="controls">
                                                                    <input type="number" name="calon[0][nomor]" class="form-control" minlength="1" aria-invalid="false"> <div class="help-block"></div>
                                                                </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <h5>Nama Pasangan<span class="text-danger">*</span></h5>
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="form-group">
                                                                <div class="controls">
                                                                    <input type="text" name="calon[0][nama]" class="form-control" minlength="1" aria-invalid="false"> <div class="help-block"></div>
                                                                </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <h5>Nama Calon Ketua<span class="text-danger">*</span></h5>
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="form-group">
                                                                <div class="controls">
                                                                    <input type="text" name="calon[0][ketua]" class="form-control" minlength="1" aria-invalid="false"> <div class="help-block"></div>
                                                                </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <h5>Nama Calon Wakil<span class="text-danger">*</span></h5>
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="form-group">
                                                                <div class="controls">
                                                                    <input type="text" name="calon[0][wakil]" class="form-control" minlength="1" aria-invalid="false"> <div class="help-block"></div>
                                                                </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <textarea class="summernote" name="calon[0][visi_misi]">
                                                                    <h3>Visi - Misi Pasangan Calon ... </h3>
                                                                </textarea>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <br>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <h5>Foto Pasangan Calon</h5>
                                                            </div>
                                                            <div class="col-md-8">
                                                                <input type="file" multiple name="calon[0][foto]" class="form-control" aria-invalid="false"> 
                                                                <div class="help-block"></div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <h5>Berkas Detail Pasangan Calon</h5>
                                                            </div>
                                                            <div class="col-md-8">
                                                                <input type="file" multiple name="calon[0][detail]" class="form-control" aria-invalid="false"> 
                                                                <div class="help-block"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <h5 class="text-white">
                                                    <a id="add_field" class="add-more btn btn-info fa fa-plus-circle">
                                                        Tambahkan Pasangan Calon Lainnya
                                                    </a>
                                                    </h5>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- <div class="row">
                                        <div class="col-md-12">
                                            <input onclick="javascript: form.action='<?php echo base_url()?>Pendaftaran/addCandidate';" class="btn btn-info " type="submit"/>
                                            <input type="hidden" name="<?=$this->security->get_csrf_token_name();?>" value="<?=$this->security->get_csrf_hash();?>" />
                                        </div>
                                        </div> -->
                                    <!-- </form> -->
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <div class="row justify-content-md-center">
                    <div class="col-md-10">
                        <!-- <div class="card card-outline-info"> -->
                            <!-- <div class="card-body"> -->

                        <input onclick="javascript: form.action='<?php echo base_url()?>Event/addEvent';" class="btn btn-info btn-block" value="Submit Event" type="submit"/>
                        <input type="hidden" name="<?=$this->security->get_csrf_token_name();?>" value="<?=$this->security->get_csrf_hash();?>" />
                            <!-- </div> -->
                        <!-- </div> -->
                    </div>
                </div>
                </form>
                
                </div>
            </div> 
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End PAge Content -->
    <!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Container fluid  -->
<!-- ==============================================================

