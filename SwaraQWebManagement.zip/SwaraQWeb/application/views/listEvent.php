<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->
<div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="row page-titles">
        <div class="col-md-5 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Dashboard</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">ListEvent</li>
            </ol>
        </div>
    </div>
    
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <?php foreach ($Event as $_Event): ?>
                    <!-- ============================================================== -->
                    <!-- Start Beasiswa Content -->
                    <!-- ============================================================== -->
                    <div class="row card">
                        <div class="col-md-8">
                           <div class="row">
                               <div class="col-8">
                                    <div class="row">
                                        <div class="col-12">
                                            <h3><strong><?php echo $_Event->Tipe?></strong></h3>
                                        </div>
                                        <div class="col-md-6">
                                            <h5>Tahun :</h5>
                                            <h4><strong><?php echo $_Event->Tahun?></strong></h4>
                                        </div>
                                        <div class="col-1-auto">
                                            <p>&nbsp;</p>
                                        </div>
                                        <div class="col-5 list-beasiswa-desc">
                                            <h5>Lokasi :</h5>
                                            <h4><strong><?php echo $_Event->Lokasi?></strong></h4>
                                        </div>
                                    </div>
                               </div>
                           </div>
                        </div>
                    </div>
                    <?php endforeach ?>
                    <div class="row">
    </div>
                    <!-- ============================================================== -->
                    <!-- End Beasiswa Content -->
                    <!-- ============================================================== -->
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End PAge Content -->
    <!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Container fluid  -->
<!-- ==============================================================