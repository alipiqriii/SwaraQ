<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo base_url() ?>assets/images/favicon.png">
    <title>SwaraQ</title>
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url() ?>assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- chartist CSS -->
    <link href="<?php echo base_url() ?>assets/plugins/chartist-js/dist/chartist.min.css" rel="stylesheet">
    <link href="<?php echo base_url() ?>assets/plugins/chartist-js/dist/chartist-init.css" rel="stylesheet">
    <link href="<?php echo base_url() ?>assets/plugins/chartist-plugin-tooltip-master/dist/
    chartist-plugin-tooltip.css" rel="stylesheet">
    <link href="<?php echo base_url() ?>assets/plugins/css-chart/css-chart.css" rel="stylesheet">
    <!--This page css - Morris CSS -->
    <link href="<?php echo base_url() ?>assets/plugins/morrisjs/morris.css" rel="stylesheet">
    <!--alerts CSS -->
    <link href="<?php echo base_url() ?>assets/plugins/sweetalert/sweetalert.css" rel="stylesheet" type="text/css">
    <!-- toast CSS -->
    <link href="<?php echo base_url() ?>assets/plugins/toast-master/css/jquery.toast.css" rel="stylesheet">
    <!-- Vector CSS -->
    <link href="<?php echo base_url() ?>/assets/plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet" />

    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
    
    <!--Form css plugins -->
    <link href="<?php echo base_url() ?>assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url() ?>assets/plugins/select2/dist/css/select2.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url() ?>assets/plugins/switchery/dist/switchery.min.css" rel="stylesheet" />
    <link href="<?php echo base_url() ?>assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" />
    <link href="<?php echo base_url() ?>assets/plugins/bootstrap-tagsinput/dist/bootstrap-tagsinput.css" rel="stylesheet" />
    <link href="<?php echo base_url() ?>assets/plugins/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.css" rel="stylesheet" />
    <link href="<?php echo base_url() ?>assets/plugins/multiselect/css/multi-select.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url() ?>assets/plugins/html5-editor/bootstrap-wysihtml5.css" rel="stylesheet" />
    <!--Form css plugins end -->

    <!-- Vector CSS -->
    <link href="<?php echo base_url() ?>assets/plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet" />
    <!-- Calendar CSS -->
    <link href="<?php echo base_url() ?>assets/plugins/calendar/dist/fullcalendar.css" rel="stylesheet" />
    <!-- summernotes CSS -->
    <link href="<?php echo base_url() ?>assets/plugins/summernote/dist/summernote.css" rel="stylesheet" />
    <!-- wysihtml5 CSS -->
    <link rel="stylesheet" href="<?php echo base_url() ?>assets/plugins/html5-editor/bootstrap-wysihtml5.css" />
    <!-- Dropzone css -->
    <link href="<?php echo base_url() ?>assets/plugins/dropzone-master/dist/dropzone.css" rel="stylesheet" type="text/css" />
    <!-- Cropper CSS -->
    <link href="<?php echo base_url() ?>assets/plugins/cropper/cropper.min.css" rel="stylesheet">

    <!-- Footable CSS -->
    <link href="<?php echo base_url() ?>assets/plugins/footable/css/footable.core.css" rel="stylesheet">
    <link href="<?php echo base_url() ?>assets/plugins/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" />

    <!-- Date picker plugins css -->
    <link href="<?php echo base_url() ?>assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.css" rel="stylesheet" type="text/css" />
    <!-- Daterange picker plugins css -->
    <link href="<?php echo base_url() ?>assets/plugins/timepicker/bootstrap-timepicker.min.css" rel="stylesheet">
    <link href="<?php echo base_url() ?>assets/plugins/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">


    <!-- Custom CSS -->
    <link href="<?php echo base_url() ?>assets/css/style.css" rel="stylesheet">
    <link href="<?php echo base_url() ?>assets/css/pojokbeasiswa.css" rel="stylesheet">
    <!-- You can change the theme colors from here -->
    <link href="<?php echo base_url() ?>assets/css/colors/blue.css" id="theme" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    
</head>

<body class="fix-header fix-sidebar card-no-border">
    
    <!-- Preloader - style you can find in spinners.css -->
    
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
            <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
    </div>
    
    <!-- Main wrapper - style you can find in pages.scss -->
    
    <div id="main-wrapper">
        
        <!-- Topbar header - style you can find in pages.scss -->
        
        <header class="topbar">
            <nav class="navbar top-navbar navbar-expand-md navbar-light">
                
                <!-- Logo -->
                
                <div class="navbar-header">
                    <h5 class="navbar-brand">
                        <a class="text-white" href="<?php echo base_url('') ?>">
                        <!-- Logo icon -->

                        <b>
                            <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                            <!-- Dark Logo icon -->
                            <!-- <img src="<?php echo base_url() ?>assets/images/logo-icon.png" alt="homepage" class="dark-logo" /> -->
                            <!-- Light Logo icon -->
                            <!-- <img src="<?php echo base_url() ?>assets/images/logo-light-icon.png" alt="homepage" class="light-logo" /> -->
                        </b>
                        <!--End Logo icon -->
                        <!-- Logo text -->

                        <span>
                            SwaraQ
                         <!-- dark Logo text -->
                         <!-- <img src="<?php echo base_url() ?>assets/images/logo-text.png" alt="homepage" class="dark-logo" /> -->
                         <!-- Light Logo text -->    
                         <!-- <img src="<?php echo base_url() ?>assets/images/logo-light-text.png" class="light-logo" alt="homepage" /> -->
                     </span> </a></h5>
                </div>
                
                <!-- End Logo -->
                
                <div class="navbar-collapse">
                    
                    <!-- toggle and nav items -->
                    
                    <ul class="navbar-nav mr-auto mt-md-0">
                        <!-- This is  -->
                        <li class="nav-item"> <a class="nav-link nav-toggler hidden-md-up text-muted waves-effect waves-dark" href="javascript:void(0)"><i class="mdi mdi-menu"></i></a> </li>
                        <li class="nav-item"> <a class="nav-link sidebartoggler hidden-sm-down text-muted waves-effect waves-dark" href="javascript:void(0)"><i class="ti-menu"></i></a> </li>

                    </ul>
                    
                    
                </div>
            </nav>
        </header>
        
        <!-- End Topbar header -->
        









        
        
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        
        <aside class="left-sidebar">
            

            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                
                
            </div>
            <!-- End Sidebar scroll-->
            <!-- Bottom points-->
            <div class="sidebar-footer">
                <!-- item-->
                <a href="#" class="link" data-toggle="tooltip" title="Settings"><i class="ti-settings"></i></a>
                <!-- item-->
                <a href="#" class="link" data-toggle="tooltip" title="Email"><i class="mdi mdi-gmail"></i></a>
                <!-- item-->
                <a href="<?php echo base_url('auth/logout') ?>" class="link" data-toggle="tooltip" title="Logout"><i class="mdi mdi-power"></i></a>
            </div>
            <!-- End Bottom points-->



        </aside>
        
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        










        <!-- Page wrapper  -->
        
        <div class="page-wrapper">




        <!-- ==========================Dynamicaly Show Main Page Content============================ -->

            <?php echo $main_content;  ?>
        
        <!-- ==========================Dynamicaly Show Main Page Content============================ -->



                
            <!-- footer -->
            
            <footer class="footer">
                © 2018 TimKemarinSore - Politeknik Negeri Bandung
            </footer>
            
            <!-- End footer -->
            
        </div>
        
        <!-- End Page wrapper  -->




    </div>


    
    <!-- End Wrapper -->
    



    
    <!-- All Jquery -->

    <script src="<?php echo base_url() ?>assets/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="<?php echo base_url() ?>assets/plugins/bootstrap/js/popper.min.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="<?php echo base_url() ?>assets/js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="<?php echo base_url() ?>assets/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="<?php echo base_url() ?>assets/js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="<?php echo base_url() ?>assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/sparkline/jquery.sparkline.min.js"></script>
    <!--Custom JavaScript -->
    <script src="<?php echo base_url() ?>assets/js/custom.min.js"></script>
    <script src="<?php echo base_url() ?>assets/js/custom.js"></script>
    
    <!-- This page plugins -->
    
    <!-- chartist chart -->
    <script src="<?php echo base_url() ?>assets/plugins/chartist-js/dist/chartist.min.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.min.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/echarts/echarts-all.js"></script>
    
    <!-- Vector map JavaScript -->
    <script src="<?php echo base_url() ?>assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
    <!-- Calendar JavaScript -->
    <script src="<?php echo base_url() ?>assets/plugins/moment/moment.js"></script>
    <script src='<?php echo base_url() ?>assets/plugins/calendar/dist/fullcalendar.min.js'></script>
    <script src="<?php echo base_url() ?>assets/plugins/calendar/dist/jquery.fullcalendar.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/calendar/dist/cal-init.js"></script>
    
    <!-- sparkline chart -->
    <script src="<?php echo base_url() ?>assets/plugins/sparkline/jquery.sparkline.min.js"></script>
    <script src="<?php echo base_url() ?>assets/js/dashboard4.js"></script>

    <!-- Sweet-Alert  -->
    <script src="<?php echo base_url() ?>assets/plugins/sweetalert/sweetalert.min.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/sweetalert/jquery.sweet-alert.custom.js"></script>
    
    <!-- toast notification CSS -->
    <script src="<?php echo base_url() ?>assets/plugins/toast-master/js/jquery.toast.js"></script>
    <script src="<?php echo base_url() ?>assets/js/toastr.js"></script>

    <!-- google maps api -->
    <script src="https://maps.google.com/maps/api/js?key=AIzaSyCUBL-6KdclGJ2a_UpmB2LXvq7VOcPT7K4&amp;sensor=true"></script>
    <script src="<?php echo base_url() ?>assets/plugins/gmaps/gmaps.min.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/gmaps/jquery.gmaps.js"></script>

    <!-- Vector map JavaScript -->
    <script src="<?php echo base_url() ?>assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/vectormap/jquery-jvectormap-in-mill.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/vectormap/jquery-jvectormap-us-aea-en.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/vectormap/jquery-jvectormap-uk-mill-en.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/vectormap/jquery-jvectormap-au-mill.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/vectormap/jvectormap.custom.js"></script>

    <!--Morris JavaScript -->
    <script src="<?php echo base_url() ?>assets/plugins/raphael/raphael-min.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/morrisjs/morris.js"></script>
    <script src="<?php echo base_url() ?>assets/js/morris-data.js"></script>
    <!-- Chart JS -->
    
    <script src="<?php echo base_url() ?>assets/plugins/Chart.js/chartjs.init.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/Chart.js/Chart.min.js"></script>

    <!-- Invoice print JS -->
    <script src="<?php echo base_url() ?>assets/js/jquery.PrintArea.js" type="text/JavaScript"></script>
    <script>
    $(document).ready(function() {
        $("#print").click(function() {
            var mode = 'iframe'; //popup
            var close = mode == "popup";
            var options = {
                mode: mode,
                popClose: close
            };
            $("div.printableArea").printArea(options);
        });
    });
    </script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

    <!-- Start Table js -->
    
    <!-- This is data table js -->
    <script src="<?php echo base_url() ?>assets/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="http://cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js"></script>
    <script src="http://cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
    <script src="http://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
    <script src="http://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
    <script src="http://cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js"></script>
    <script src="http://cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js"></script>
    <script>
    $(document).ready(function() {
        $('#myTable').DataTable();
        $(document).ready(function() {
            var table = $('#example').DataTable({
                "columnDefs": [{
                    "visible": false,
                    "targets": 2
                }],
                "order": [
                    [2, 'asc']
                ],
                "displayLength": 25,
                "drawCallback": function(settings) {
                    var api = this.api();
                    var rows = api.rows({
                        page: 'current'
                    }).nodes();
                    var last = null;
                    api.column(2, {
                        page: 'current'
                    }).data().each(function(group, i) {
                        if (last !== group) {
                            $(rows).eq(i).before('<tr class="group"><td colspan="5">' + group + '</td></tr>');
                            last = group;
                        }
                    });
                }
            });
            // Order by the grouping
            $('#example tbody').on('click', 'tr.group', function() {
                var currentOrder = table.order()[0];
                if (currentOrder[0] === 2 && currentOrder[1] === 'asc') {
                    table.order([2, 'desc']).draw();
                } else {
                    table.order([2, 'asc']).draw();
                }
            });
        });
    });
    $('#example23').DataTable({
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    });
    </script>

    <!-- Editable datatable-->
    <script src="<?php echo base_url() ?>assets/plugins/jquery-datatables-editable/jquery.dataTables.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/datatables/dataTables.bootstrap.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/tiny-editable/mindmup-editabletable.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/tiny-editable/numeric-input-example.js"></script>
    <script>
    $('#mainTable').editableTableWidget().numericInputExample().find('td:first').focus();
    $('#editable-datatable').editableTableWidget().numericInputExample().find('td:first').focus();
    $(document).ready(function() {
        $('#editable-datatable').DataTable();
    });
    </script>

    <!-- End Table js -->





    <!-- Start Forms js -->

    <script src="<?php echo base_url() ?>assets/js/validation.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/summernote/dist/summernote.min.js"></script>
    <script>
    ! function(window, document, $) {
        "use strict";
        $("input,select,textarea").not("[type=submit]").jqBootstrapValidation(), $(".skin-square input").iCheck({
            checkboxClass: "icheckbox_square-green",
            radioClass: "iradio_square-green"
        }), $(".touchspin").TouchSpin(), $(".switchBootstrap").bootstrapSwitch();
    }(window, document, jQuery);
    </script>

    <script src="<?php echo base_url() ?>assets/plugins/switchery/dist/switchery.min.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url() ?>assets/plugins/bootstrap-select/bootstrap-select.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url() ?>assets/plugins/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js"></script>
    <script src="<?php echo base_url() ?>assets/plugins/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="../assets/plugins/multiselect/js/jquery.multi-select.js"></script>
    <script>
    jQuery(document).ready(function() {

        //summernone text editor
        jQuery(document).ready(function() {

        $('.summernote').summernote({
            height: 350, // set editor height
            minHeight: null, // set minimum height of editor
            maxHeight: null, // set maximum height of editor
            focus: false // set focus to editable area after initializing summernote
        });

        $('.inline-editor').summernote({
            airMode: true
            });

        });

        // Switchery
        var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
        $('.js-switch').each(function() {
            new Switchery($(this)[0], $(this).data());
        });
        // For select 2
        $(".select2").select2();
        $('.selectpicker').selectpicker();
        //Bootstrap-TouchSpin
        $(".vertical-spin").TouchSpin({
            verticalbuttons: true,
            verticalupclass: 'ti-plus',
            verticaldownclass: 'ti-minus'
        });
        var vspinTrue = $(".vertical-spin").TouchSpin({
            verticalbuttons: true
        });
        if (vspinTrue) {
            $('.vertical-spin').prev('.bootstrap-touchspin-prefix').remove();
        }
        $("input[name='tch1']").TouchSpin({
            min: 0,
            max: 100,
            step: 0.1,
            decimals: 2,
            boostat: 5,
            maxboostedstep: 10,
            postfix: '%'
        });
        $("input[name='tch2']").TouchSpin({
            min: -1000000000,
            max: 1000000000,
            stepinterval: 50,
            maxboostedstep: 10000000,
            prefix: '$'
        });
        $("input[name='tch3']").TouchSpin();
        $("input[name='tch3_22']").TouchSpin({
            initval: 40
        });
        $("input[name='tch5']").TouchSpin({
            prefix: "pre",
            postfix: "post"
        });
        // For multiselect
        $('#pre-selected-options').multiSelect();
        $('#optgroup').multiSelect({
            selectableOptgroup: true
        });
        $('#public-methods').multiSelect();
        $('#select-all').click(function() {
            $('#public-methods').multiSelect('select_all');
            return false;
        });
        $('#deselect-all').click(function() {
            $('#public-methods').multiSelect('deselect_all');
            return false;
        });
        $('#refresh').on('click', function() {
            $('#public-methods').multiSelect('refresh');
            return false;
        });
        $('#add-option').on('click', function() {
            $('#public-methods').multiSelect('addOption', {
                value: 42,
                text: 'test 42',
                index: 0
            });
            return false;
        });
        $(".ajax").select2({
            ajax: {
                url: "https://api.github.com/search/repositories",
                dataType: 'json',
                delay: 250,
                data: function(params) {
                    return {
                        q: params.term, // search term
                        page: params.page
                    };
                },
                processResults: function(data, params) {
                    // parse the results into the format expected by Select2
                    // since we are using custom formatting functions we do not need to
                    // alter the remote JSON data, except to indicate that infinite
                    // scrolling can be used
                    params.page = params.page || 1;
                    return {
                        results: data.items,
                        pagination: {
                            more: (params.page * 30) < data.total_count
                        }
                    };
                },
                cache: true
            },
            escapeMarkup: function(markup) {
                return markup;
            }, // let our custom formatter work
            minimumInputLength: 1,
            templateResult: formatRepo, // omitted for brevity, see the source of this page
            templateSelection: formatRepoSelection // omitted for brevity, see the source of this page
        });
    });
    </script>
    <!-- End form js -->


    <script type="text/javascript">
        $(document).ready(function(){
            var id = 0;
            $('.itemName').select2({
                placeholder: '-- Nama Kampus --',
                ajax:{
                    url: "<?php echo base_url(); ?>/Formulir/lookup",
                    dataType: "json",
                    delay: 250,
                    data: function(params){
                        return{
                            q: params.term
                        };
                    },
                    processResults: function(data){
                        var results = [];

                        $.each(data, function(index, item){
                            results.push({
                                id: item.NPSN,
                                text: item.Nama_Sekolah
                            });
                        });
                        return{
                            results: results
                        };
                    }
                }
            });

            $('.itemName').on('change', function(){
                $('.nomorIndukSekolah').val($(this).val());
                // $('.nomorIndukSekolah').prop('disabled', true);
                $('.inputManualSekolah').prop('disabled', true);
            });

            $('.clear-select').on('click', function(){
                $('.itemName').select2('data', {id: null, text: null});
                $('.itemName').html('');
                $('.nomorIndukSekolah').val('');
                $('.nomorIndukSekolah').prop('disabled', false);
                $('.inputManualSekolah').prop('disabled', false);
            });
        });
    </script>
    <script type="text/javascript">
        var counter = 0;
        function Remove_University(){
            $('#Remove_University').click(function(e) {
                e.preventDefault(); 
                $(this).closest('.card').remove(); 
                counter-=1;
            });
        }
        $(function(){
            $('#add_field').click(function(){
                counter += 1;
                $('#Paslon_Form').append( '<div class="card card-outline-info">'+
                '    <div class="card-header" id="Remove_University">'+
                '        <h5 class="mb-0 text-white ">'+
                '<span class="d-inline">Pasangan Calon '+ (counter+1) +'</span>'+
                '<span onclick="Remove_University()" class="d-inline-block btn btn-danger float-right fa fa-close"></span>'+
                '        </h5> '+
                '    </div>'+
                '<div class="card-body">'+
                '    '+
                '    <h5>Nomor Pasangan<span class="text-danger">*</span></h5>'+
                '    <div class="row">'+
                '        <div class="col-md-12">'+
                '            <div class="form-group">'+
                '            <div class="controls">'+
                '                <input type="number" name="calon['+ counter +'][nomor]" class="form-control" minlength="1" aria-invalid="false"> <div class="help-block"></div>'+
                '            </div>'+
                '            </div>'+
                '        </div>'+
                '    </div>'+
                '    <h5>Nama Pasangan<span class="text-danger">*</span></h5>'+
                '    <div class="row">'+
                '        <div class="col-md-12">'+
                '            <div class="form-group">'+
                '            <div class="controls">'+
                '                <input type="text" name="calon['+ counter +'][nama]" class="form-control" minlength="1" aria-invalid="false"> <div class="help-block"></div>'+
                '            </div>'+
                '            </div>'+
                '        </div>'+
                '    </div>'+
                ''+
                '    <h5>Nama Calon Ketua<span class="text-danger">*</span></h5>'+
                '    <div class="row">'+
                '        <div class="col-md-12">'+
                '            <div class="form-group">'+
                '            <div class="controls">'+
                '                <input type="text" name="calon['+ counter +'][ketua]" class="form-control" minlength="1" aria-invalid="false"> <div class="help-block"></div>'+
                '            </div>'+
                '            </div>'+
                '        </div>'+
                '    </div>'+
                '    <h5>Nama Calon Wakil<span class="text-danger">*</span></h5>'+
                '    <div class="row">'+
                '        <div class="col-md-12">'+
                '            <div class="form-group">'+
                '            <div class="controls">'+
                '                <input type="text" name="calon['+ counter +'][wakil]" class="form-control" minlength="1" aria-invalid="false"> <div class="help-block"></div>'+
                '            </div>'+
                '            </div>'+
                '        </div>'+
                '    </div>'+
                '    <div class="row">'+
                '        <div class="col-md-12">'+
                '<textarea id="summernote'+counter+'" name="calon['+ counter +'][visi_misi]">'+
                                                                    '<h3>Visi - Misi Pasangan Calon ... </h3>'+
                                                                '</textarea>'+
                '        </div>'+
                '    </div>'+
                '    <div class="row">'+
                '        <div class="col-md-12">'+
                '            <br>'+
                '        </div>'+
                '    </div>'+
                '    <div class="row">'+
                '        <div class="col-md-4">'+
                '            <h5>Foto Pasangan Calon</h5>'+
                '        </div>'+
                '        <div class="col-md-8">'+
                '            <input type="file" multiple name="calon['+ counter +'][foto]" class="form-control" aria-invalid="false"> '+
                '            <div class="help-block"></div>'+
                '        </div>'+
                '    </div>'+
                '    <div class="row">'+
                '        <div class="col-md-4">'+
                '            <h5>Berkas Detail Pasangan Calon</h5>'+
                '        </div>'+
                '        <div class="col-md-8">'+
                '            <input type="file" multiple name="calon['+ counter +'][detail]" class="form-control" aria-invalid="false"> '+
                '            <div class="help-block"></div>'+
                '        </div>'+
                '    </div>'+
                '</div>'
                );
                $(document).ready(function(){
                    $('#summernote'+counter).summernote();
                });
            });
        });
    </script> 

    <!-- <script type="text/javascript">


      $('.itemName').select2({
        placeholder: '--- Select Item ---',
        ajax: {
          url: 'http://localhost/metrovic_admin/Formulir/lookup',
          dataType: 'json',
          delay: 250,
          processResults: function (data) {
            return {
              results: data
            };
          },
          cache: true
        }
      });


    </script> -->



    <!-- auto hide message div-->
    <script type="text/javascript">
        $( document ).ready(function(){
           $('.delete_msg').delay(3000).slideUp();
        });
    </script>



    <!-- Style switcher -->
    
    <script src="<?php echo base_url() ?>assets/plugins/styleswitcher/jQuery.style.switcher.js"></script>
    <script type="text/javascript">
    $(function() {
        // $(":checkbox").on("change", function() {
            

        
    });
    
    </script>
    <script type="text/javascript">
    function checkBox_accordion(identifier) {
        
        var checkBox = document.getElementById('Box_'+identifier);
        var content = document.getElementById(identifier);

        if (identifier.includes('Accordion_Universitas')){
            if (checkBox.checked == true){
                $('#' + 'Accordion_Universitas').slideDown();

            } else {
                $('#' + 'Accordion_Universitas').slideUp();
            }
        }
        else {
            if (checkBox.checked == true){
                $('#' + identifier).slideDown();

            } else {
                $('#' + identifier).slideUp();
            }
        }
        if($('#Box_Accordion_SD').is(':checked')|| $('#Box_Accordion_SMP').is(':checked') 
            || $('#Box_Accordion_SMK').is(':checked')){
                $('#NISN').slideDown();
            }
            else $('#NISN').slideUp();
            if($('#Box_Accordion_Universitas1').is(':checked') || $('#Box_Accordion_Universitas2').is(':checked')
                || $('#Box_Accordion_Universitas3').is(':checked') || $('#Box_Accordion_Universitas4').is(':checked')
                || $('#Box_Accordion_Universitas5').is(':checked') || $('#Box_Accordion_Universitas6').is(':checked')){
                    $('#NIM').slideDown();
            }
            else $('#NIM').slideUp();

    

    }
    $('#Remove_University').click(function(e) {
        e.preventDefault(); 
        $(this).closest('.card').remove(); 
        counter-=1;
    });
    </script>
    <script type="text/javascript">
    var _id = 0;
    var _id_surat = 0;
    $(function(){

            $('#add_berkas').click(function(){
                
                $('#Berkas').append(
                '<div class="row" id="Surat_Field_'+_id+'">'+
                '<div class="col-md-1" id="Remove_Berkas'+_id+'">'+
                '    <a onclick="Remove_Berkas('+_id+')" class="text-white btn btn-danger fa fa-close"></a>'+
                '</div>'+
                '    <div class="col-md-5">'+
                '        <input type="text" name="berkas[]" placeholder="nama berkas" class="form-group">'+
                '        <div class="help-block"></div>'+
                '   </div>'+
                '    <div class="col-md-5">'+
                '        <input multiple type="file" name="berkas[]" class="form-group">'+
                '        <div class="help-block"></div>'+
                '   </div>'+
                '</div>'
                );
                _id_surat+=1;
                
            });
        });
    $(function(){

            $('#add_surat').click(function(){
                
                $('#Surat').append(
                '<div class="row" id="Surat_Field_'+_id+'">'+
                '<div class="col-md-1" id="Remove_Berkas'+_id+'">'+
                '    <a onclick="Remove_Berkas('+_id+')" class="text-white btn btn-danger fa fa-close"></a>'+
                '</div>'+
                '    <div class="col-md-5">'+
                '        <input type="text" name="namasurat[]" placeholder="namasurat" class="form-group">'+
                '        <div class="help-block"></div>'+
                '   </div>'+
                '    <div class="col-md-5">'+
                '        <input multiple type="file" name="surat[]" class="form-group">'+
                '        <div class="help-block"></div>'+
                '   </div>'+
                '</div>'
                );
                _id_surat+=1;
                
            });
        });
    function Remove_Surat(id){
        $('#Remove_Berkas'+id).click(function(e) {
            e.preventDefault(); 
            $(this).closest('.row').remove(); 
            _id_surat-=1;
        });
    }
    
    function Remove_Berkas(id){
        $('#Remove_Berkas'+id).click(function(e) {
            e.preventDefault(); 
            $(this).closest('.row').remove(); 
            _id-=1;
        });
    }
    
    function Berkas(id,type) {
        var content_value;
        switch(type) {
            case 'Tipe_Berkas':
                content_value = document.getElementById('Tipe_Berkas_'+id);
                break;
            case 'Jenjang_Berkas':
                content_value = document.getElementById('Jenjang_Berkas_'+id);
                break;
            case 'Skala_Sertifikat':
                content_value = document.getElementById('Skala_Sertifikat_'+id);
                break;
        }

        if(content_value.value == 'Ijazah') {
            if(document.getElementById('Jenjang_Berkas_'+id+'') != null) $('#Berkas_Field_'+id+' > div').slice(2).remove();
        $('#Berkas_Field_'+id+'').append( '<div class="col-md-3">'+
            '    <div class="controls">'+
            '        <select name="Jenjang[]" id="Jenjang_Berkas_'+id+'" required="" class="form-control" aria-invalid="false">'+
            '            <option value="">Jenjang</option>'+
            '            <option value="SD">SD/MI</option>'+
            '            <option value="SMP">SMP/MTS</option>'+
            '            <option value="SMA">SMA/SMK/MA</option>'+
            '            <option value="Universitas">Universitas/Politeknik</option>'+
            '        </select>'+
            '        <div class="help-block"></div>'+
            '    </div>'+
            '</div>'+
            '<div class="col-md-5">'+
            '    <div class="controls">'+
            '    </div>'+
            '       <input type="file" name="Berkas[]" class="form-control" aria-invalid="false">'+
            '    <div class="help-block"></div>'+
            '</div></div>'
            );
        }

        else if(content_value.value == 'SKHUN') {
            if(document.getElementById('Jenjang_Berkas_'+id+'') != null) $('#Berkas_Field_'+id+' > div').slice(2).remove();
        $('#Berkas_Field_'+id+'').append( 
            '<div class="col-md-3">'+
            '    <div class="controls">'+
            '        <select name="Jenjang[]" id="Jenjang_Berkas_'+id+'" required="" class="form-control" aria-invalid="false">'+
            '            <option value="">Jenjang</option>'+
            '            <option value="SD">SD/MI</option>'+
            '            <option value="SMP">SMP/MTS</option>'+
            '            <option value="SMA">SMA/SMK/MA</option>'+
            '            <option value="Universitas">Universitas/Politeknik</option>'+
            '        </select>'+
            '        <div class="help-block"></div>'+
            '    </div>'+
            '</div>'+
            '<div class="col-md-5">'+
            '    <input type="file" name="Berkas[]" class="form-control" aria-invalid="false">'+
            '</div></div>'

            
            );
        }

        else if(content_value.value == 'Sertifikat') {
            if(document.getElementById('Jenjang_Berkas_'+id+'') != null) $('#Berkas_Field_'+id+' > div').slice(2).remove();
        
        $('#Berkas_Field_'+id+'').append( 
            '<div class="col-md-3">'+
            '    <div class="controls">'+
            '        <select name="Jenjang[]" id="Jenjang_Berkas_'+id+'" required="" class="form-control" aria-invalid="false">'+
            '            <option value="">Jenjang</option>'+
            '            <option value="SD">SD/MI</option>'+
            '            <option value="SMP">SMP/MTS</option>'+
            '            <option value="SMA">SMA/SMK/MA</option>'+
            '            <option value="Universitas">Universitas/Politeknik</option>'+
            '        </select>'+
            '        <div class="help-block"></div>'+
            '       </div>'+
            '   </div>'+
            '   <div class="col-md-5">'+
            '       <input type="file" name="Berkas[]" class="form-control" aria-invalid="false"/>'+
            '   </div>'+
            '</div>'+
            '<div class="row">'+
            '    <div class="col-md-2">'+
            '    </div>'+
            '    <div class="col-md-5">'+
            '        <select name="skala[]" id="Skala_Berkas_'+id+'" required="" class="form-control" aria-invalid="false">'+
            '            <option value="">Skala</option>'+
            '            <option value="Kecamatan">Kecamatan</option>'+
            '            <option value="Kabupaten">Kabupaten/Kota</option>'+
            '            <option value="Provinsi">Provinsi</option>'+
            '            <option value="Nasional">Nasional</option>'+
            '            <option value="Nasional">Internasional</option>'+
            '        </select>'+
            '    </div>'+
            '    <div class="col-md-5">'+
            '       <input type="text" name="keterangan[]" class="form-control" placeholder="Keterangan Sertifikat"/>'+
            '    </div>'+
            '</div>'
            );
        }
        else if(content_value.value == '' && document.getElementById('Jenjang_Berkas_'+id) != null 
            && $('#Berkas_Field_'+id+' > div').length > 1 ){
            $('#Berkas_Field_'+id+' > div').slice(2).remove();
        }
    }
    </script>
</body>

</html>
