<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event extends CI_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->model('common_model');
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->load->library('upload');
    }

    public function index(){
        $data = array();
        $data['page_title'] = 'Event';
        $data['main_content'] = $this->load->view('addEvent', $data, TRUE);
        $this->load->view('index', $data);
    }

    public function listEvent(){
        $data = array();
        $data['page_title'] = 'Event';
        $data['Event'] = $this->common_model->data();
        $data['main_content'] = $this->load->view('listEvent', $data, TRUE);
        $this->load->view('index', $data);
    }

    public function addEvent(){
        if ($_POST) {
            $data = array(      
                'Tipe'         => $_POST['tipe_pemilihan'],
                'Tahun'        => $_POST['tahun_pemilihan'],
                'Lokasi'       => $_POST['lokasi']
            );

            $data = $this->security->xss_clean($data);
            $PdaftarID = $this->common_model->insert($data, 'EventPemilihan');
            $LastID = $this->db->insert_id();
            $this->session->set_flashdata('msg', 'Identitas Diri Berhasil Disimpan');
            

            foreach($_POST['calon'] as $row=>$value){

                $_FILES['userfile']['name']     = $LastID.'_'.$value['nomor'].'_FOTO_'.$_FILES['calon']['name'][$row]['foto'];
                $_FILES['userfile']['name'] = str_replace(' ', '_', $_FILES['userfile']['name']);
                $_FILES['userfile']['type']     = $_FILES['calon']['type'][$row]['foto'];
                $_FILES['userfile']['tmp_name'] = $_FILES['calon']['tmp_name'][$row]['foto'];
                $_FILES['userfile']['error']    = $_FILES['calon']['error'][$row]['foto'];
                $_FILES['userfile']['size']     = $_FILES['calon']['size'][$row]['foto'];
                $foto = $_FILES['userfile']['name'];

                $this->upload->initialize($this->set_upload_image());
                $this->upload->do_upload();

                // $name = str_replace(' ', '_', $name);
                $_FILES['userfile']['name']     = $LastID.'_'.$value['nomor'].'_Detail_'.$_FILES['calon']['name'][$row]['detail'];
                $_FILES['userfile']['name'] = str_replace(' ', '_', $_FILES['userfile']['name']);
                $_FILES['userfile']['type']     = $_FILES['calon']['type'][$row]['detail'];
                $_FILES['userfile']['tmp_name'] = $_FILES['calon']['tmp_name'][$row]['detail'];
                $_FILES['userfile']['error']    = $_FILES['calon']['error'][$row]['detail'];
                $_FILES['userfile']['size']     = $_FILES['calon']['size'][$row]['detail'];
                $detail = $_FILES['userfile']['name'];

                $this->upload->initialize($this->set_upload_options());
                $this->upload->do_upload();

                $data = array(
                "EventID"        => $LastID,
                "NomorPasangan"  => $value['nomor'],
                "NamaPasangan"   => $value['nama'],
                "NamaKetua"      => $value['ketua'],
                "NamaWakil"      => $value['wakil'],
                "VisiMisi"       => $value['visi_misi'],
                "Foto"           => $foto,
                "DetailBerkas"   => $detail
                );
                // print_r ($row); 
                $data = $this->security->xss_clean($data);
                $PdaftarID = $this->common_model->insert($data, 'PasanganCalon');
            }
            echo "<script>Swal(
              'Berhasil!',
              'Data Berhasil Ditambahkan',
              'success'
            )setTimeout(3000)</script>";
            redirect(base_url(''));
        }
    }

    private function set_upload_options()
    {   
        //upload an image options
        $config = array();

        $config['upload_path'] = './assets/berkas/';
        $config['allowed_types'] = '*';
        $config['max_size']      = '0';
        $config['overwrite']     = TRUE;


        return $config;
    }
    
    private function set_upload_image()
    {   
        //upload an image options
        $config = array();

        $config['upload_path'] = './assets/images/';
        $config['allowed_types'] = '*';
        $config['max_size']      = '0';
        $config['overwrite']     = TRUE;

        return $config;
    }
}